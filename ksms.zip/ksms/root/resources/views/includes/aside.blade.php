<!-- start: sidebar -->
<aside id="sidebar-left" class="sidebar-left no-print">
    <div class="sidebar-header">
        <div class="sidebar-title">
            Navigation
        </div>
        <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
            <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
        </div>
    </div>
    <div class="nano">
        <div class="nano-content">
            <nav id="menu" class="nav-main" role="navigation">
                <ul class="nav nav-main">
                    <li class="{{ isActive('/') }}">
                        <a href="{{ url('/') }}">
                            <i class="fa fa-tachometer" aria-hidden="true"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                    <li class="nav-parent {{ isActive(['programs*']) }}">
                        <a>
                            <i class="fa fa-ship" aria-hidden="true"></i>
                            <span>Parent</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="{{ isActive('programs') }}">
                                <a href="{{action('ProgramController@index')}}">Child</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent {{ isActive(['user*']) }}">
                        <a>
                            <i class="fa fa-users" aria-hidden="true"></i>
                            <span>User Management</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="{{ isActive('users') }}">
                                <a href="{{ action('UserController@index') }}">Users</a>
                            </li>
                            <li class="{{ isActive('user/create')}}">
                                <a href="{{ action('UserController@create') }}">Add User</a>
                            </li>
                            <li class="{{ isActive('user/change')}}">
                                <a href="{{ action('UserController@changePassword') }}">Change Password</a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-parent {{ isActive(['companies*']) }}">
                        <a>
                            <i class="fa fa-users" aria-hidden="true"></i>
                            <span>Company Management</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="{{ isActive('companies') }}">
                                <a href="{{ action('CompanyController@index') }}">Companies</a>
                            </li>
                            <li class="{{ isActive('company/create')}}">
                                <a href="{{ action('CompanyController@create') }}">Add Company</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
    </div>

</aside>
<!-- end: sidebar -->

