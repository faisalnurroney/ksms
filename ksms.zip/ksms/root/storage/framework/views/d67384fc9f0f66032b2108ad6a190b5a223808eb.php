<?php $__env->startSection('title','Rotation List'); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">

        <header class="page-header no-print">
            <h2>Program Rotation Report</h2>
            <div class="right-wrapper pull-right">
                <ol class="breadcrumbs">
                    <li>
                        <a>
                            <i class="fa fa-home"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                </ol>
                <a class="sidebar-right-toggle" ><i class="fa fa-chevron-left"></i></a>
            </div>
        </header>

        <!-- Search Panel -->
        <div class="panel panel-body no-print">
            <?php echo Form::open(['action'=>'ProgramController@rotation','method'=>'get','class'=>'form-inline']); ?>

            <div class="form-group <?php echo e($errors->has('date')?'has-error':''); ?>">
                <label class="control-label">Program Date: </label>
                    <div class="input-group">
                <span class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                </span>
                        <?php echo e(Form::text('date', null, array('class' => 'form-control','data-plugin-datepicker data-date-format="yyyy-mm-dd"','placeholder'=>'YYYY-MM-DD' ))); ?>

                    </div>
                    <?php if($errors->has('date')): ?>
                        <span class="help-block"><strong><?php echo e($errors->first('date')); ?></strong></span>
                    <?php endif; ?>
                </div>
                <?php echo Form::submit('GO',['class'=>'btn btn-success']); ?>

                <a href="javascript:window.print()" class="btn btn-success" role="button"><i class="fa fa-print"></i></a>
            <?php echo Form::close(); ?>

        </div>
        <!-- /Search Panel -->

        <section class="panel">
            <header class="panel-heading">
                <div class="panel-actions">
                    <a href="javascript:window.print()"><i class="fa fa-print"></i></a>
                    <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                </div>
                <h2 class="panel-title">Rotation Report</h2>
            </header>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-condensed mb-none">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Vehicle</th>
                            <th>Status</th>
                            <th>Location</th>
                            <th>Driver Adv. Fixed</th>
                            <th>SR</th>
                            <th>Party</th>
                            <th>Empty Container</th>
                            <th>Vehicle Mobile</th>
                            <th>Loading Point</th>
                            <th>Unloading Point</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Advance</th>
                            <th>Due</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($vehicle->id); ?></td>
                                <td><?php echo e($vehicle->vehicleNo); ?></td>
                                <td><?php echo e(isset($vehicle->status->name) ? $vehicle->status->name : ''); ?></td>
                                <?php $__currentLoopData = $vehicle->trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($trip->program->date == $date): ?>
                                        <td><?php echo e(isset($trip->program->unloading) ? $trip->program->unloading : ''); ?></td>
                                        <td class="text-right"><?php echo e(isset($trip->driver_adv) ? $trip->driver_adv : 0); ?>/-</td>
                                        <td><?php echo e(isset($trip->program->employee->name) ? $trip->program->employee->name : ''); ?></td>
                                        <td><?php echo e(isset($trip->program->party->name) ? $trip->program->party->name : ''); ?></td>
                                        <td><?php echo e(isset($trip->program->emp_container) ? $trip->program->emp_container : ''); ?></td>
                                        <td><?php echo e(isset($vehicle->mobile) ? $vehicle->mobile : ''); ?></td>
                                        <td><?php echo e(isset($trip->program->loading) ? $trip->program->loading : ''); ?></td>
                                        <td><?php echo e(isset($trip->program->unloading) ? $trip->program->unloading : ''); ?></td>
                                        <td><?php echo e(isset($trip->program->product) ? $trip->program->product : ''); ?></td>
                                        <td class="text-right"><?php echo e(number_format($trip->program->rent)); ?>/-</td>
                                        <td class="text-right"><?php echo e(number_format($trip->program->adv_rent)); ?>/-</td>
                                        <td class="text-right"><?php echo e(number_format($trip->program->due_rent)); ?>/-</td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div><br>
            </div>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function confirmDelete(){
            var x = confirm('Are you sure you want to delete this record?');
            return !!x;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>