
<div class="form-group <?php echo e($errors->has('date')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Date:</label>
    <div class="col-md-6">
        <div class="input-group">
                <span class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                </span>
            <?php echo e(Form::text('date', null, array('class' => 'form-control','data-plugin-datepicker data-date-format="yyyy-mm-dd"' ))); ?>

        </div>
        <?php if($errors->has('date')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('date')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>

<div class="form-group <?php echo e($errors->has('vehicle_id')?'has-error':''); ?>">
    <?php echo e(Form::label('vehicle_id', 'Vehicle No. :', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('vehicle_id',$repository->vehicles(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select Vehicle Number'])); ?>

        <?php if($errors->has('vehicle_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('vehicle_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>

<div class="form-group <?php echo e($errors->has('description')? 'has-error':''); ?>">
    <?php echo e(Form::label('description','Description:',['class'=>'col-md-3 control-label'])); ?>

    <div class="col-md-6">
        <?php echo e(Form::textarea('description', null, ['class' => 'form-control'])); ?>

        <?php if($errors->has('description')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('description')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>

<div class="form-group">
    <div class="col-md-2 col-md-offset-3">
        <?php echo e(Form::submit('Save',['class'=>'form-control btn btn-success'])); ?>

    </div>
    <div class="col-md-2">
        
        <?php echo e(Form::reset('Reset',['class'=>'form-control btn btn-warning'])); ?>

    </div>
    <div class="col-md-2">
        
        <a href="<?php echo e(URL::previous()); ?>" role="button" class="form-control btn btn-danger">Back</a>
    </div>
</div>
<!-- ends-->