<?php $__env->startSection('title','Companies'); ?>

<?php $__env->startSection('content'); ?>

    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Companies</h2>

            <div class="right-wrapper pull-right">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(url('/home')); ?>">
                            <i class="fa fa-home"></i>
                        </a>
                    </li>
                    <li><span>Companies</span></li>
                </ol>

                <a class="sidebar-right-toggle" data-open=""><i class="fa fa-chevron-left"></i></a>
            </div>
        </header>

        <section class="panel">
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <header class="panel-heading">
                <div class="panel-actions">
                    <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                    
                </div>
                <h2 class="panel-title">All Companies</h2>
            </header>
            <div class="panel-body">
                <table class="table table-no-more table-bordered table-striped mb-none">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th class="hidden-xs hidden-sm">Name</th>
                        <th class="text-right">Address</th>
                        <th class="text-right hidden-xs hidden-sm">City</th>
                        <th class="text-right">State</th>
                        <th class="text-right">Country</th>
                        <th class="text-right">Phone</th>
                        <th class="text-right hidden-xs hidden-sm">Action</th>
                        
                        
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-title="ID"><?php echo e($company->id); ?></td>
                            <td data-title="Date"><?php echo e($company->name); ?></td>
                            <td data-title="Address" class="hidden-xs hidden-sm"><?php echo e($company->address); ?></td>
                            <td data-title="City Name" class="text-right"><?php echo e($company->city->name); ?></td>
                            <td data-title="Qty" class="text-right hidden-xs hidden-sm"><?php echo e($company->state->name); ?></td>
                            <td data-title="Price" class="text-right"><?php echo e($company->country->name); ?></td>
                            <td data-title="Total" class="text-right"><?php echo e($company->phone); ?></td>
                            <td data-title="Action" class="text-right hidden-xs hidden-sm">
                                <?php echo Form::open(['action'=>['CompanyController@destroy',$company->id],'method'=>'delete','onsubmit'=>'return confirmDelete()']); ?>

                                <?php echo Form::submit('X',['class'=>'btn btn-danger']); ?>

                                <a href="<?php echo e(action('CompanyController@edit',$company->id)); ?>" role="button" class="btn btn-warning"><span class="fa fa-edit"></span></a>
                                <?php echo Form::close(); ?>

                            </td>
                            
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </section>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        function confirmDelete(){
            var x = confirm('Do you want to delete this company?');
            return !!x;
        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>