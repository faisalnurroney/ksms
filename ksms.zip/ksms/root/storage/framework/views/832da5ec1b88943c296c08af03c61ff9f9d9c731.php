<?php $__env->startSection('title','Products'); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Add Products</h2>
            <div class="right-wrapper pull-right">
                <ol class="breadcrumbs">
                    <li>
                        <a>
                            <i class="fa fa-home"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                </ol>
                <a class="sidebar-right-toggle" ><i class="fa fa-chevron-left"></i></a>
            </div>
        </header>
        <div class="row">
            <div class="col-md-12">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <!-- start: page -->


        <div class="row">
            <div class="col-xs-12">
                <section class="panel">


                    <!-- Search Panel -->
                    <div class="panel panel-body no-print">
                        <?php echo Form::open(['action'=>'ProgramController@dailyIncomeReport','method'=>'get','class'=>'form-inline']); ?>

                        <div class="form-group <?php echo e($errors->has('date')?'has-error':''); ?>">
                            <label class="control-label">Program Date: </label>
                            <div class="input-group">
                <span class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                </span>
                                <?php echo e(Form::text('date', null, array('class' => 'form-control','data-plugin-datepicker data-date-format="yyyy-mm-dd"','placeholder'=>'YYYY-MM-DD' ))); ?>

                            </div>
                            <?php if($errors->has('date')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('date')); ?></strong></span>
                            <?php endif; ?>
                        </div>
                        <?php echo Form::submit('GO',['class'=>'btn btn-success']); ?>

                        <a href="javascript:window.print()" class="btn btn-success" role="button"><i class="fa fa-print"></i></a>
                        <?php echo Form::close(); ?>

                    </div>
                    <!-- /Search Panel -->

                    <header class="panel-heading">
                        <div class="panel-actions">
                            <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                        </div>
                        <h2 class="panel-title">List of Expenses</h2>
                    </header>

                    <div class="panel-body">
                        
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-condensed mb-none">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Date</th>
                                    <th>Category</th>
                                    <th>Description</th>
                                    <th>Amount</th>
                                    <th class="text-center">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($expense->id); ?></td>
                                        <td><?php echo e($expense->date); ?></td>
                                        <td><?php echo e($expense->expenseCategory->name); ?></td>
                                        <td><?php echo e($expense->description); ?></td>
                                        <td class="text-right"><?php echo e($expense->amount); ?>/-</td>
                                        <td class="text-center">
                                            <?php echo e(Form::open(['action'=>['ExpenseController@destroy',$expense->id],'method'=>'delete','onsubmit'=>'return confirmDelete()'])); ?>

                                            <a href="<?php echo e(action('ExpenseController@edit',$expense->id)); ?>" role="button" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                            <?php echo e(Form::submit('X',['class'=>'btn btn-danger'])); ?>

                                            <?php echo e(Form::close()); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="4" class="text-right">Total Expense</td>
                                        <td class="text-right"><?php echo e($total); ?>/-</td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>
            </div>
        </div>

    </section>
    <!-- end: page -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function confirmDelete(){
            var x = confirm('Are you sure you want to delete this record?');
            return !!x;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>