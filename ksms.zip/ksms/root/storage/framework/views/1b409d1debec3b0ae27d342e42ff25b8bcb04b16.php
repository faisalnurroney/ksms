<?php $__env->startSection('title','Parties'); ?>

<?php $__env->startSection('content'); ?>
        <section role="main" class="content-body">
            <header class="page-header">
                <h2>Dashboard</h2>
                <div class="right-wrapper pull-right">
                    <ol class="breadcrumbs">
                        <li>
                            <a>
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li><span>Party</span></li>
                    </ol>
                    <a class="sidebar-right-toggle" ><i class="fa fa-chevron-left"></i></a>
                </div>
            </header>

            <div class="row">
                <div class="col-xs-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                            </div>
                            <h2 class="panel-title">List of Parties</h2>
                        </header>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <a href="<?php echo e(action('PartyController@create')); ?>" role="button" class="btn btn-success">Add Party</a><br />
                                <table class="table table-bordered table-striped table-condensed mb-none">
                                    <thead>
                                    <tr>
                                    <th>ID</th>
                                    <th>Party Name</th>
                                    <th>Contact Person</th>
                                    <th>Address</th>
                                    <th>E-mail</th>
                                    <th>Contact Number</th>
                                    <th>Action</th>
                             </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($party->id); ?></td>
                                    <td><?php echo e($party->name); ?></td>
                                    <td><?php echo e($party->contact_person); ?></td>
                                    <td><?php echo e($party->address); ?></td>
                                    <td><?php echo e($party->email); ?></td>
                                    <td><?php echo e($party->mobile); ?></td>
                                    <td>
                                        <?php echo e(Form::open(['action'=>['PartyController@destroy',$party->id],'method'=>'delete','onsubmit'=>'return confirmDelete()'])); ?>

                                        <a href="<?php echo e(action('PartyController@edit',$party->id)); ?>" role="button" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                        <?php echo e(Form::submit('X',['class'=>'btn btn-danger'])); ?>

                                        <?php echo e(Form::close()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                                </table>
                            </div>
                        </div>
                    </section>
                    </div>
                </div>
            </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
function confirmDelete(){
    var x = confirm('Are you sure you want to delete this record?');
    return !!x;
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>