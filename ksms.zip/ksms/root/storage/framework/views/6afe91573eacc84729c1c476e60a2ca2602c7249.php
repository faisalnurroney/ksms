<div class="form-group <?php echo e($errors->has('name')? 'has-error':''); ?>">
    <?php echo e(Form::label('name', 'Name:', ['class'=>'col-md-3 control-label'])); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('name', null, ['class' => 'form-control','required'])); ?>

        <?php if($errors->has('name')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('name')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>

<div class="form-group <?php echo e($errors->has('description')? 'has-error':''); ?>">
    <?php echo e(Form::label('description','Description:',['class'=>'col-md-3 control-label'])); ?>

    <div class="col-md-6">
        <?php echo e(Form::textarea('description', null, ['class' => 'form-control'])); ?>

        <?php if($errors->has('description')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('description')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>

<div class="form-group">
    <div class="col-md-2 col-md-offset-3">
        <?php echo e(Form::submit('Save',['class'=>'form-control btn btn-success'])); ?>

    </div>
    <div class="col-md-2">
        
        <?php echo e(Form::reset('Reset',['class'=>'form-control btn btn-warning'])); ?>

    </div>
    <div class="col-md-2">
        
        <a href="<?php echo e(URL::previous()); ?>" role="button" class="form-control btn btn-danger">Back</a>
    </div>
</div>
<!-- ends-->