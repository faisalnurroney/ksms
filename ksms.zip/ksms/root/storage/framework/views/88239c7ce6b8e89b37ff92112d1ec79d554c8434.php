<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">

        <header class="page-header">
            <h2>Dashboard</h2>
            <div class="right-wrapper pull-right">
                <ol class="breadcrumbs">
                    <li>
                        <a>
                            <i class="fa fa-home"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                </ol>
                <a class="sidebar-right-toggle" ><i class="fa fa-chevron-left"></i></a>
            </div>
        </header>

        <section class="panel">
            <header class="panel-heading">
                <div class="panel-actions">
                    <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                    
                </div>

                <h2 class="panel-title">Vehicle Information</h2>
            </header>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-condensed mb-none">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Owner</th>
                            <th>Road Permit</th>
                            <th>TAX Token</th>
                            <th>Insurance</th>
                            <th>Fitness</th>
                            <th>Reg. Certificate</th>
                            <th>Numbers</th>
                            <th>Status</th>
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($vehicle->id); ?></td>
                            <td><?php echo e($vehicle->name); ?></td>
                            <td>
                                <?php echo e(isset($vehicle->brand->name) ? $vehicle->brand->name : ''); ?>

                                <?php echo e(isset($vehicle->type->name) ? $vehicle->type->name : ''); ?>

                            </td>
                            <td><?php echo e(isset($vehicle->owner->name) ? $vehicle->owner->name : ''); ?></td>
                            <td>
                                <?php echo e($vehicle->roadPermitStart); ?>

                                <?php echo e($vehicle->roadPermitEnd); ?>

                            </td>
                            <td>
                                <?php echo e($vehicle->taxTokenStart); ?>

                                <?php echo e($vehicle->taxTokenEnd); ?>

                            </td>
                            <td>
                                <?php echo e($vehicle->insuranceStart); ?>

                                <?php echo e($vehicle->insuranceEnd); ?>

                            </td>
                            <td>
                                <?php echo e($vehicle->fitnessStart); ?>

                                <?php echo e($vehicle->fitnessEnd); ?>

                            </td>
                            <td>
                                <?php echo e($vehicle->regCertStart); ?>

                                <?php echo e($vehicle->regCertEnd); ?>

                            </td>
                            <td>
                                <?php echo e($vehicle->vehicleNo); ?>

                                <?php echo e($vehicle->engineNo); ?>

                                <?php echo e($vehicle->chasesNo); ?>

                            </td>
                            <td>
                                <?php echo e(isset($vehicle->status->name) ? $vehicle->status->name : ''); ?>

                            </td>
                            <td>
                                
                            </td>
                            <td>
                                <?php echo e(Form::open(['action'=>['VehicleController@destroy',$vehicle->id],'method'=>'delete','onsubmit'=>'return confirmDelete()'])); ?>

                                <a href="<?php echo e(action('VehicleController@edit',$vehicle->id)); ?>" role="button" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                <?php echo e(Form::submit('X',['class'=>'btn btn-danger'])); ?>

                                <?php echo e(Form::close()); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function confirmDelete(){
            var x = confirm('Are you sure you want to delete this record?');
            return !!x;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>