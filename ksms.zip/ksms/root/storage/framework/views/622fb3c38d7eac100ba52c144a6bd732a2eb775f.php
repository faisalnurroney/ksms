<?php $__env->startSection('content'); ?>
        <section role="main" class="content-body">
            <header class="page-header">
                <h2>Categories</h2>
                <div class="right-wrapper pull-right">
                    <ol class="breadcrumbs">
                        <li>
                            <a>
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li><span>Categories</span></li>
                    </ol>
                    <a class="sidebar-right-toggle" ><i class="fa fa-chevron-left"></i></a>
                </div>
            </header>
            <!-- start: page -->
            <div class="row">
                <div class="col-xs-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                            </div>
                            <h2 class="panel-title">Category</h2>
                        </header>

                        <div class="panel-body">
                            <?php echo e(Form::model($category,['action'=>['CategoryController@update',$category->id],'method'=>'patch','class'=>'form-horizontal'])); ?>

                            <div class="form-group <?php echo e($errors->has('name')? 'has-error':''); ?>">
                                <?php echo e(Form::label('name','Category Name:',['class'=>'col-md-3 control-label'])); ?>

                                <div class="col-md-6">
                                    <?php echo e(Form::text('name',null,['class' => 'form-control'])); ?>

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block"><strong><?php echo e($errors->first('name')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group <?php echo e($errors->has('description')? 'has-error':''); ?>">
                                <?php echo e(Form::label('description','Description:',['class'=>'col-md-3 control-label'])); ?>

                                <div class="col-md-6">
                                    <?php echo e(Form::textarea('description',null,['class' => 'form-control'])); ?>

                                    <?php if($errors->has('description')): ?>
                                        <span class="help-block"><strong><?php echo e($errors->first('description')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-2 col-md-offset-3">
                                    <?php echo e(Form::submit('Update',['class'=>'form-control btn btn-success'])); ?>

                                </div>
                                <div class="col-md-2">
                                    <?php echo e(Form::reset('Reset',['class'=>'form-control btn btn-warning'])); ?>

                                </div>
                                <div class="col-md-2">
                                    <a href="<?php echo e(URL::previous()); ?>" role="button" class="form-control btn btn-danger">Back</a>
                                </div>
                            </div>
                            <!-- ends-->
                            <?php echo e(Form::close()); ?>

                        </div>
                    </section>
                </div>
            </div>

            <div class="row">
                <div class="col-xs-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                            </div>
                            <h2 class="panel-title">Categories</h2>
                        </header>
                        <div class="col-md-12">
                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-condensed mb-none">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($category->id); ?></td>
                                            <td><?php echo e($category->name); ?></td>
                                            <td><?php echo e($category->description); ?></td>
                                            <td>
                                                <?php echo e(Form::open(['action'=>['CategoryController@destroy',$category->id],'method'=>'delete'])); ?>

                                                <a href="<?php echo e(action('CategoryController@edit',$category->id)); ?>" role="button" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                                <?php echo e(Form::submit('X',['class'=>'btn btn-danger'])); ?>

                                                <?php echo e(Form::close()); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </section>
                </div>
            </div>


        </section>
    <!-- end: page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>