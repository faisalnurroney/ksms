<?php $__env->startSection('content'); ?>
    <div class="inner-wrapper" style="margin-top: -700px;;">
        <section role="main" class="content-body">
            <table width="100%" class="display table table-striped table-bordered table-hover" id="example" cellspacing="0">
                    <thead>
                        <caption><center><h2>Vehicle Brands & Description</h2></center></caption>
                        <tr>
                                <th>ID</th>
                                <th>Brand Name</th>
                                <th>Description</th>
                         </tr>
                    </thead>
                 
                    <tbody>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($d->id); ?></td>
                        <td><?php echo e($d->brand); ?></td>
                        <td><?php echo e($d->description); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
            </table>
        </section>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>