<?php $__env->startSection('title','Purchase Edit'); ?>

<?php $__env->startSection('content'); ?>
        <section role="main" class="content-body">
            <header class="page-header">
                <h2>Edit Purchase</h2>
                <div class="right-wrapper pull-right">
                    <ol class="breadcrumbs">
                        <li>
                            <a>
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li><span>Edit Purchase</span></li>
                    </ol>
                    <a class="sidebar-right-toggle" ><i class="fa fa-chevron-left"></i></a>
                </div>
            </header>
            <!-- start: page -->
            <div class="row">
                <div class="col-xs-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                            </div>
                            <h2 class="panel-title">Purchase Update Form</h2>
                        </header>

                        <div class="panel-body">
                            <?php echo e(Form::model($invoice,['action'=>['InvoiceController@update',$invoice->id],'method'=>'patch','class'=>'form-horizontal'])); ?>

                            <?php echo $__env->make('invoice.form',['submitButtonText'=>'Update'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php echo e(Form::close()); ?>

                        </div>
                    </section>
                </div>
            </div>
        </section>
    <!-- end: page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>