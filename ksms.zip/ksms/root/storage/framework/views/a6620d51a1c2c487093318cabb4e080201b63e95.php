<!--Date starts-->
<div class="form-group <?php echo e($errors->has('date')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Program Date:</label>
    <div class="col-md-6">
        <div class="input-group">
                <span class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                </span>
            <?php echo e(Form::text('date', null, array('class' => 'form-control','data-plugin-datepicker data-date-format="yyyy-mm-dd"' ))); ?>

        </div>
        <?php if($errors->has('date')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('date')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>

<!--Date ends-->

<!-- party start-->
<div class="form-group <?php echo e($errors->has('party_id')?'has-error':''); ?>">
    <?php echo e(Form::label('party_id', 'Party Name:', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('party_id',$repository->parties(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select Party'])); ?>

        <?php if($errors->has('party_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('party_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- party ends-->

<!-- Program ID Starts-->
<div class="form-group <?php echo e($errors->has('program_id')?'has-error':''); ?>">
    <?php echo e(Form::label('program_id', 'Program ID', ['class'=>'col-md-3 control-label'])); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('program_id',$repository->programs(),null,['class'=>'form-control populate','id' =>'program_id','data-plugin-selectTwo','placeholder'=>'Select Program'])); ?>

        <?php if($errors->has('program_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('program_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Program ID ends-->


<!-- Total Rent Starts-->
<div class="form-group <?php echo e($errors->has('rent')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Total Rent:</label>
    <div class="col-md-6">
        <?php echo e(Form::text('rent',null, array('class' => 'form-control','id'=>'rent','readonly'))); ?>

        <?php if($errors->has('rent')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('rent')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Total Rent ends-->

<!-- Advance Rent Starts-->
<div class="form-group <?php echo e($errors->has('adv_rent')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Advance Rent:</label>
    <div class="col-md-6">
        <?php echo e(Form::text('adv_rent',null, array('class' => 'form-control','id'=>'adv_rent','readonly'))); ?>

        <?php if($errors->has('adv_rent')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('adv_rent')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Advance Rent ends-->

<!-- Due Rent Starts-->
<div class="form-group <?php echo e($errors->has('due_rent')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Due Rent:</label>
    <div class="col-md-6">
        <?php echo e(Form::text('due_rent',null, ['class' => 'form-control','id'=>'due_rent','readonly'])); ?>

        <?php if($errors->has('due_rent')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('due_rent')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Due Rent ends-->

<!-- Payable Amount Starts-->
<div class="form-group <?php echo e($errors->has('paid')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Payable Amount:</label>
    <div class="col-md-6">
        <?php echo e(Form::text('paid',null, array('class' => 'form-control','id'=>'paid'))); ?>

        <?php if($errors->has('paid')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('paid')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Payable Amount ends-->

<!--Submit button -->
<div class="form-group">
    <div class="col-md-2 col-md-offset-3">
        <?php echo e(Form::submit($submitButtonText,['class'=>'form-control btn btn-success'])); ?>

    </div>
    <div class="col-md-2">
        <?php echo e(Form::reset('Reset',['class'=>'form-control btn btn-warning'])); ?>

    </div>
    <div class="col-md-2">
        <a href="<?php echo e(URL::previous()); ?>" role="button" class="form-control btn btn-danger">Back</a>
    </div>
</div>
<!-- ends-->

