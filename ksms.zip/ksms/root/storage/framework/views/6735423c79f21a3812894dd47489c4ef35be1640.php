<?php $__env->startSection('title','Purchases'); ?>

<?php $__env->startSection('content'); ?>
        <section role="main" class="content-body">
            <header class="page-header">
                <h2>Dashboard</h2>
                <div class="right-wrapper pull-right">
                    <ol class="breadcrumbs">
                        <li>
                            <a>
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li><span>Purchase</span></li>
                    </ol>
                    <a class="sidebar-right-toggle" ><i class="fa fa-chevron-left"></i></a>
                </div>
            </header>

            <div class="row">
                <div class="col-xs-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                            </div>
                            <h2 class="panel-title">List of Purchases</h2>
                        </header>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <a href="<?php echo e(action('PurchaseController@create')); ?>" role="button" class="btn btn-success">New Purchase</a><br />
                                <table class="table table-bordered table-striped table-condensed mb-none">
                                    <thead>
                                    <tr>
                                    <th>ID</th>
                                    <th>Date</th>
                                    <th>Supplier</th>
                                    <th>Voucher</th>
                                    <th>Vehicle No</th>
                                    <th>Category</th>
                                    <th>Parts</th>
                                    <th>Brand</th>
                                    <th>Quantity</th>
                                    <th>Rate</th>
                                    <th>Total</th>
                                    <th>Paid</th>
                                    <th>Due</th>
                                    <th>Actions</th>
                             </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($purchase->id); ?></td>
                                    <td><?php echo e($purchase->date); ?></td>
                                    <td><?php echo e(isset($purchase->supplier->supplier_name) ? $purchase->supplier->supplier_name : ''); ?></td>
                                    <td><?php echo e(isset($purchase->voucher) ? $purchase->voucher : ''); ?></td>
                                    <td><?php echo e(isset($purchase->vehicle->vehicleNo) ? $purchase->vehicle->vehicleNo : ''); ?></td>
                                    <td><?php echo e(isset($purchase->category->name) ? $purchase->category->name : ''); ?></td>
                                    <td><?php echo e(isset($purchase->parts->name) ? $purchase->parts->name : ''); ?></td>
                                    <td><?php echo e(isset($purchase->brand->name) ? $purchase->brand->name : ''); ?></td>
                                    <td><?php echo e(isset($purchase->quantity) ? $purchase->quantity : ''); ?></td>
                                    <td><?php echo e(isset($purchase->rate) ? $purchase->rate : ''); ?></td>
                                    <td><?php echo e(isset($purchase->total) ? $purchase->total : ''); ?></td>
                                    <td><?php echo e(isset($purchase->advance) ? $purchase->advance : ''); ?></td>
                                    <td><?php echo e(isset($purchase->due) ? $purchase->due : ''); ?></td>
                                  <td>
                                        <?php echo e(Form::open(['action'=>['PurchaseController@destroy',$purchase->id],'method'=>'delete','onsubmit'=>'return confirmDelete()'])); ?>

                                        <a href="<?php echo e(action('PurchaseController@edit',$purchase->id)); ?>" role="button" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                        <?php echo e(Form::submit('X',['class'=>'btn btn-danger'])); ?>

                                        <?php echo e(Form::close()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="10" class="text-right">Total</td>
                                    <td><?php echo e($total); ?></td>
                                    <td><?php echo e($paid); ?></td>
                                    <td><?php echo e($due); ?></td>
                                    <td></td>
                                </tr>
                        </tbody>
                                </table>
                            </div>
                        </div>
                    </section>
                    </div>
                </div>
            </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
function confirmDelete(){
    var x = confirm('Are you sure you want to delete this record?');
    return !!x;
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>