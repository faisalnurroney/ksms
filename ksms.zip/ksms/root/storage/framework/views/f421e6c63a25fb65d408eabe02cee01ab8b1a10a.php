<?php $__env->startSection('title','Add Driver'); ?>

<?php $__env->startSection('content'); ?>
        <section role="main" class="content-body">
            <header class="page-header">
                <h2>Add Driver</h2>
                <div class="right-wrapper pull-right">
                    <ol class="breadcrumbs">
                        <li>
                            <a>
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li><span>Add Driver</span></li>
                    </ol>
                    <a class="sidebar-right-toggle" ><i class="fa fa-chevron-left"></i></a>
                </div>
            </header>
            <!-- start: page -->
            <div class="row">
                <div class="col-xs-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                            </div>
                            <h2 class="panel-title">Driver Information Form</h2>
                        </header>

                        <div class="panel-body">
                            <?php echo e(Form::model($driver = new \App\Driver,['action' => 'DriverController@store','method'=>'post','class'=>'form-horizontal','files'=>true])); ?>

                            <?php echo $__env->make('driver.form',['submitButtonText'=>'Save'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php echo e(Form::close()); ?>

                        </div>
                    </section>
                </div>
            </div>
        </section>
    </div>
    <!-- end: page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>