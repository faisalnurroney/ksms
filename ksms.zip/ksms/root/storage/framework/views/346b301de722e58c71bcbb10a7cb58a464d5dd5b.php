<!-- Program ID Starts-->
<div class="form-group <?php echo e($errors->has('program_id')?'has-error':''); ?>">
    <?php echo e(Form::label('program_id', 'Program ID', ['class'=>'col-md-3 control-label'])); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('program_id',$repository->programs(),null,['class'=>'form-control populate','id' =>'program_id','data-plugin-selectTwo','placeholder'=>'Select Program'])); ?>

        <?php if($errors->has('program_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('program_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Program ID ends-->

<!-- Fuel Cost Starts-->
<div class="form-group <?php echo e($errors->has('fuel_cost')?'has-error':''); ?>">
    <?php echo e(Form::label('fuel_cost', 'Fuel Cost', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('fuel_cost', null, array('class' => 'form-control','id' =>'fuel_cost'))); ?>

        <?php if($errors->has('fuel_cost')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('fuel_cost')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Fuel Cost ends-->

<!-- Driver Allowance  Starts-->
<div class="form-group <?php echo e($errors->has('driver_allow')?'has-error':''); ?>">
    <?php echo e(Form::label('driver_allow', 'Driver Allowance', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('driver_allow', null, array('class' => 'form-control','id' =>'driver_allow'))); ?>

        <?php if($errors->has('driver_allow')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('driver_allow')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Helper Salary ends-->

<!-- Helper Allowance  Starts-->
<div class="form-group <?php echo e($errors->has('helper_allow')?'has-error':''); ?>">
    <?php echo e(Form::label('helper_allow', 'Helper Allowance', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('helper_allow', null, array('class' => 'form-control','id' =>'helper_allow'))); ?>

        <?php if($errors->has('helper_allow')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('helper_allow')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Helper Allowance ends-->

<!-- Labour load unload  Starts-->
<div class="form-group <?php echo e($errors->has('labour')?'has-error':''); ?>">
    <?php echo e(Form::label('labour', 'Labour Load Unload', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('labour', null, array('class' => 'form-control','id' =>'labour'))); ?>

        <?php if($errors->has('labour')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('labour')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Labour load unload ends-->

<!-- Toll  Starts-->
<div class="form-group <?php echo e($errors->has('toll')?'has-error':''); ?>">
    <?php echo e(Form::label('toll', 'Toll', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('toll', null, array('class' => 'form-control','id' =>'toll'))); ?>

        <?php if($errors->has('toll')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('toll')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Toll ends-->

<!-- Bridge  Starts-->
<div class="form-group <?php echo e($errors->has('bridge')?'has-error':''); ?>">
    <?php echo e(Form::label('bridge', 'Bridge', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('bridge', null, array('class' => 'form-control','id' =>'bridge'))); ?>

        <?php if($errors->has('bridge')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('bridge')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Bridge ends-->

<!-- Scale  Starts-->
<div class="form-group <?php echo e($errors->has('scale')?'has-error':''); ?>">
    <?php echo e(Form::label('scale', 'Scale', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('scale', null, array('class' => 'form-control','id' =>'scale'))); ?>

        <?php if($errors->has('scale')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('scale')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Scale ends-->

<!-- Wheel maintenance  Starts-->
<div class="form-group <?php echo e($errors->has('wheel')?'has-error':''); ?>">
    <?php echo e(Form::label('wheel', 'Wheel Maintenance', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('wheel', null, array('class' => 'form-control','id' =>'wheel'))); ?>

        <?php if($errors->has('wheel')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('wheel')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Wheel maintenance ends-->

<!-- Guard/bazar chada Starts-->
<div class="form-group <?php echo e($errors->has('donation')?'has-error':''); ?>">
    <?php echo e(Form::label('donation', 'Guard/Bazar Donation', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('donation', null, array('class' => 'form-control','id' =>'donation'))); ?>

        <?php if($errors->has('donation')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('donation')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Guard/bazar chada ends-->

<!-- Container Charge  Starts-->
<div class="form-group <?php echo e($errors->has('container')?'has-error':''); ?>">
    <?php echo e(Form::label('container', 'Container Charge', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('container', null, array('class' => 'form-control','id' =>'container'))); ?>

        <?php if($errors->has('container')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('container')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Container Charge ends-->

<!-- Port gate  Starts-->
<div class="form-group <?php echo e($errors->has('port_gate')?'has-error':''); ?>">
    <?php echo e(Form::label('port_gate', 'Post Gate Charge', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('port_gate', null, array('class' => 'form-control','id' =>'port_gate'))); ?>

        <?php if($errors->has('port_gate')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('port_gate')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Port gate Charge ends-->

<!-- Other Expenses  Starts-->
<div class="form-group <?php echo e($errors->has('other')?'has-error':''); ?>">
    <?php echo e(Form::label('other', 'Other Expenses', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('other', null, array('class' => 'form-control','id' =>'other'))); ?>

        <?php if($errors->has('other')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('other')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Other Expenses ends-->

<!-- Total Expense  Starts-->
<div class="form-group <?php echo e($errors->has('total')?'has-error':''); ?>">
    <?php echo e(Form::label('total', 'Total Expense', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('total', null, array('class' => 'form-control','id' =>'total','readonly'))); ?>

        <?php if($errors->has('total')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('other')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Total Expense
ends-->

<!--Submit button -->
<div class="form-group">
    <div class="col-md-2 col-md-offset-3">
        <?php echo e(Form::submit($submitButtonText,['class'=>'form-control btn btn-success'])); ?>

    </div>
    <div class="col-md-2">
        <?php echo e(Form::reset('Reset',['class'=>'form-control btn btn-warning'])); ?>

    </div>
    <div class="col-md-2">
        <a href="<?php echo e(URL::previous()); ?>" role="button" class="form-control btn btn-danger">Back</a>
    </div>
</div>
<!-- ends-->


<?php $__env->startSection('script'); ?>
    <script>
        $(document).keyup(function () {
            var fuel = $('#fuel_cost').val();
            var driver_allow = $('#driver_allow').val();
            var helper_allow = $('#helper_allow').val();
            var labour = $('#labour').val();
            var toll = $('#toll').val();
            var bridge = $('#bridge').val();
            var scale = $('#scale').val();
            var wheel = $('#wheel').val();
            var donation = $('#donation').val();
            var container = $('#container').val();
            var other = $('#other').val();
            var port_gate = $('#port_gate').val();
            $('#total').val(parseInt(fuel)+
                            parseInt(driver_allow)+
                            parseInt(helper_allow)+
                            parseInt(labour)+
                            parseInt(toll)+
                            parseInt(bridge)+
                            parseInt(scale)+
                            parseInt(wheel)+
                            parseInt(donation)+
                            parseInt(container)+
                            parseInt(other)+
                            parseInt(port_gate));
        })
    </script>
<?php $__env->stopSection(); ?>