<?php $__env->startSection('content'); ?>
    <div class="inner-wrapper" style="margin-top: -650px;">
        <section role="main" class="content-body">
            <!-- start: page -->
            <div class="row">
                <div class="col-xs-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                            </div>
                            <h2 class="panel-title">Status of Vehicle</h2>
                        </header>

                        <div class="panel-body">
                            <?php echo e(Form::open(array('action' => 'StatusController@store','method'=>'post'))); ?>

                            <!-- Brand Name Starts-->
                            <div class="form-group">
                                <?php echo e(Form::label('name', 'Status Name:', array('class'=>'col-md-3 control-label'))); ?>

                                
                                <div class="col-md-6">
                                    <?php echo e(Form::text('name', null, array('class' => 'form-control'))); ?>

                                </div>
                            </div>
                            <!-- Brand name ends-->

                            <div class="form-group">
                                <div class="col-md-2 col-md-offset-3">
                                    <input type="submit" value="Save"  class="form-control btn btn-success">
                                </div>
                                <div class="col-md-2">
                                    <input type="reset" value="Reset"  class="form-control btn btn-warning">
                                </div>
                                <div class="col-md-2">
                                    <input type="Button" value="Cancel"  class="form-control btn btn-danger">
                                </div>
                            </div>
                            <!-- ends-->
                            <?php echo e(Form::close()); ?>

                        </div>
                    </section>
                </div>
            </div>
        </section>
    </div>
    <!-- end: page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>