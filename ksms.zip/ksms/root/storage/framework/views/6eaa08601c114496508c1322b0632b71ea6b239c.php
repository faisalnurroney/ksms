
<!-- Brand  Starts -->
<div class="form-group <?php echo e($errors->has('brand_id') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('brand', 'Brand:', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('brand_id',$repository->brands(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select Brands'])); ?>

        <?php if($errors->has('brand_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('brand_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Brand ends -->

<!-- Categories  Starts -->
<div class="form-group <?php echo e($errors->has('category_id') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('category', 'Category:', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('category_id',$repository->categories(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select Categories'])); ?>

        <?php if($errors->has('category_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('category_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!--Categories ends -->

<!-- Parts  Starts -->
<div class="form-group <?php echo e($errors->has('parts_id') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('parts', 'Parts:', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('parts_id',$repository->parts(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select Part'])); ?>

        <?php if($errors->has('parts_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('parts_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!--Parts ends -->

<!-- Parts  Starts -->
<div class="form-group <?php echo e($errors->has('unit_id') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('part', 'Unit:', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('unit_id',$repository->units(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select Unit'])); ?>

        <?php if($errors->has('unit_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('unit_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!--Parts ends -->

<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('name', 'Product Name:', ['class'=>'col-md-3 control-label'])); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('name', null, ['class' => 'form-control','required'])); ?>

        <?php if($errors->has('name')): ?>
            <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
        <?php endif; ?>
    </div>
</div>
<div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('description','Description:',['class'=>'col-md-3 control-label'])); ?>

    <div class="col-md-6">
        <?php echo e(Form::textarea('description', null, ['class' => 'form-control'])); ?>

        <?php if($errors->has('description')): ?>
            <span class="help-block">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
        <?php endif; ?>
    </div>
</div>

<div class="form-group">
    <div class="col-md-2 col-md-offset-3">
        <?php echo e(Form::submit('Save',['class'=>'form-control btn btn-success'])); ?>

    </div>
    <div class="col-md-2">
        
        <?php echo e(Form::reset('Reset',['class'=>'form-control btn btn-warning'])); ?>

    </div>
    <div class="col-md-2">
        
        <a href="<?php echo e(URL::previous()); ?>" role="button" class="form-control btn btn-danger">Back</a>
    </div>
</div>
<!-- ends-->