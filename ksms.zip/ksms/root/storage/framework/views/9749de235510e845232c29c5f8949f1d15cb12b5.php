<?php $__env->startSection('content'); ?>
    <div class="inner-wrapper" style="margin-top: -500px;;">
        <section role="main" class="content-body">
            <table width="100%" class="display table table-striped table-bordered table-hover" id="example" cellspacing="0">
                    <thead>
                        <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Brand Name</th>
                                <th>Type</th>
                                <th>Owner Name</th>
                                <th>Road Permit Start Date</th>
                                <th>Road Permit End Date</th>
                                <th>Tax Token Start Date</th>
                                <th>Tax Token End Date</th>
                                <th>Insurance Start Date</th>
                                <th>Insurance End Date</th>
                                <th>Fitness Start Date</th>
                                <th>Fitness End Date</th>
                                <th>Reg. Certificate Start Date</th>
                                <th>Reg. Certificate End Date</th>
                                <th>Vehicle No</th>
                                <th>Engine No</th>
                                <th>Chases No</th>
                                <th>Status</th>
                         </tr>
                    </thead>
                    <tbody>
                <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($d->id); ?></td>
                            <td><?php echo e($d->name); ?></td>
                            <td><?php echo e($d->brand_name); ?></td>
                            <td><?php echo e($d->type); ?></td>
                            <td><?php echo e($d->owner_name); ?></td>
                            <td><?php echo e($d->roadPermitStart->format("d-m-y")); ?></td>
                            <td><?php echo e($d->roadPermitEnd->format("d-m-y")); ?></td>
                            <td><?php echo e($d->taxTokenStart->format("d-m-y")); ?></td>
                            <td><?php echo e($d->taxTokenEnd->format("d-m-y")); ?></td>
                            <td><?php echo e($d->insuranceStart->format("d-m-y")); ?></td>
                            <td><?php echo e($d->insuranceEnd->format("d-m-y")); ?></td>
                            <td><?php echo e($d->fitnessStart->format("d-m-y")); ?></td>
                            <td><?php echo e($d->fitnessEnd->format("d-m-y")); ?></td>
                            <td><?php echo e($d->regCertStart->format("d-m-y")); ?></td>
                            <td><?php echo e($d->regCertEnd->format("d-m-y")); ?></td>
                            <td><?php echo e($d->vehicleNo); ?></td>
                            <td><?php echo e($d->engineNo); ?></td>
                            <td><?php echo e($d->chasesNo); ?></td>
                            <td><?php echo e($d->status); ?></td>

                        </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
            </table>
        </section>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>