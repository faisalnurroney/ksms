<!-- start: sidebar -->
<aside id="sidebar-left" class="sidebar-left no-print">
    <div class="sidebar-header">
        <div class="sidebar-title">
            Navigation
        </div>
        <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
            <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
        </div>
    </div>
    <div class="nano">
        <div class="nano-content">
            <nav id="menu" class="nav-main" role="navigation">
                <ul class="nav nav-main">
                    <li class="<?php echo e(isActive('/')); ?>">
                        <a href="<?php echo e(url('/')); ?>">
                            <i class="fa fa-tachometer" aria-hidden="true"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['employees*','employee*','designation*'])); ?>">
                        <a>
                            <i class="fa fa-id-card-o" aria-hidden="true"></i>
                            <span>Employee</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('employees')); ?>">
                                <a href="<?php echo e(action('EmployeeController@index')); ?>">Employee Information</a>
                            </li>
                            <li class="<?php echo e(isActive('employee/create')); ?>">
                                <a href="<?php echo e(action('EmployeeController@create')); ?>">Add Employee</a>
                            </li>
                            <li class="<?php echo e(isActive('designations')); ?>">
                                <a href="<?php echo e(action('DesignationController@index')); ?>">Add Designation</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['vehicleUserAssigns*','vehicleUserAssign/create*'])); ?>">
                        <a>
                            <i class="fa fa-drivers-license" aria-hidden="true"></i>
                            <span>Vehicle Assignation</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('vehicleUserAssigns')); ?>">
                                <a href="<?php echo e(action('VehicleUserAssignController@index')); ?>">List of vehicles</a>
                            </li>
                            <li class="<?php echo e(isActive('vehicleUserAssign/show')); ?>">
                                <a href="<?php echo e(action('VehicleUserAssignController@create')); ?>">Assign Vehicle</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['drivers*','driver*'])); ?>">
                        <a>
                            <i class="fa fa-drivers-license" aria-hidden="true"></i>
                            <span>Driver</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('drivers')); ?>">
                                <a href="<?php echo e(action('DriverController@index')); ?>">Driver Information</a>
                            </li>
                            <li class="<?php echo e(isActive('driver/create')); ?>">
                                <a href="<?php echo e(action('DriverController@create')); ?>">Add Driver</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['vehicles','vehicle/create','brand*','type*','status*'])); ?>">
                        <a>
                            <i class="fa fa-truck" aria-hidden="true"></i>
                            <span>Vehicle</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('vehicles')); ?>">
                                <a href="<?php echo e(action('VehicleController@index')); ?>">Vehicle Information</a>
                            </li>
                            <li class="<?php echo e(isActive('vehicle/create')); ?>">
                                <a href="<?php echo e(action('VehicleController@create')); ?>">Add Vehicle</a>
                            </li>
                            <li class="<?php echo e(isActive('brands')); ?>">
                                <a href="<?php echo e(action('BrandController@index')); ?>">Brand</a>
                            </li>
                            <li class="<?php echo e(isActive('types')); ?>">
                                <a href="<?php echo e(action('TypeController@index')); ?>">Type</a>
                            </li>
                            <li class="<?php echo e(isActive('statuses')); ?>">
                                <a href="<?php echo e(action('StatusController@index')); ?>">Status</a>
                            </li>
                            <li class="<?php echo e(isActive('vehicleDailyReport')); ?>">
                                <a href="<?php echo e(action('VehicleController@report')); ?>">Vehicle Daily Report</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['owners*','owner*'])); ?>">
                        <a>
                            <i class="fa fa-user-secret" aria-hidden="true"></i>
                            <span>Owner</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('owners')); ?>">
                                <a href="<?php echo e(action('OwnerController@index')); ?>">Owner</a>
                            </li>
                            <li class="<?php echo e(isActive('owner/create')); ?>">
                                <a href="<?php echo e(action('OwnerController@create')); ?>">Add Owner</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['party*','parties*'])); ?>">
                        <a>
                            <i class="fa fa-handshake-o" aria-hidden="true"></i>
                            <span>Parties</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('parties')); ?>">
                                <a href="<?php echo e(action('PartyController@index')); ?>">Party list</a>
                            </li>
                            <li class="<?php echo e(isActive('party/create')); ?>">
                                <a href="<?php echo e(action('PartyController@create')); ?>">Add Party</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['program*','dailyReport*','trip*','rotation*','dailyIncomeReport*','report*','receipt*'])); ?>">
                        <a>
                            <i class="fa fa-ship" aria-hidden="true"></i>
                            <span>Programs</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('programs')); ?>">
                                <a href="<?php echo e(action('ProgramController@index')); ?>">Program list</a>
                            </li>
                            <li class="<?php echo e(isActive('program/create')); ?>">
                                <a href="<?php echo e(action('ProgramController@create')); ?>">Add Program</a>
                            </li>
                            <li class="<?php echo e(isActive('tripCosts')); ?>">
                                <a href="<?php echo e(action('TripCostController@index')); ?>">Trip Cost list</a>
                            </li>
                            <li class="<?php echo e(isActive('tripCost/create')); ?>">
                                <a href="<?php echo e(action('TripCostController@create')); ?>">Add Trip Cost</a>
                            </li>
                            <li class="<?php echo e(isActive('program/rotation')); ?>">
                                <a href="<?php echo e(action('ProgramController@rotation')); ?>">Rotation</a>
                            </li>

                            <li class="<?php echo e(isActive('program/dailyIncomeReport')); ?>">
                                <a href="<?php echo e(action('ProgramController@dailyIncomeReport')); ?>">Daily Income Report</a>
                            </li>

                            
                            
                            
                            <li class="<?php echo e(isActive('program/receipt')); ?>">
                                <a href="<?php echo e(action('ProgramController@driverReceipt')); ?>">Accounting From Driver</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['accounts*','due/create*'])); ?>">
                        <a>
                            <i class="fa fa-money" aria-hidden="true"></i>
                            <span>Accounts</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('due/create')); ?>">
                                <a href="<?php echo e(action('DueController@create')); ?>">Due Collection</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['expense/create*','expenseCategories*','expense/dail*'])); ?>">
                        <a>
                            <i class="fa fa-money" aria-hidden="true"></i>
                            <span>Expenses</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('expense/create')); ?>">
                                <a href="<?php echo e(action('ExpenseController@create')); ?>">Add Expense</a>
                            </li>
                            <li class="<?php echo e(isActive('expenseCategories')); ?>">
                                <a href="<?php echo e(action('ExpenseCategoryController@index')); ?>">Add Category</a>
                            </li>
                            <li class="<?php echo e(isActive('expense/dailyReport')); ?>">
                                <a href="<?php echo e(action('ExpenseController@index')); ?>">Daily Expense Report</a>
                            </li>
                        </ul>
                    </li>


                    <li class="nav-parent <?php echo e(isActive(['parts*','productBrands*','categories*','products*','product/create*'])); ?>">
                        <a>
                            <i class="fa fa-gift" aria-hidden="true"></i>
                            <span>Products</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('products')); ?>">
                                <a href="<?php echo e(action('ProductController@index')); ?>">Product List</a>
                            </li>
                            <li class="<?php echo e(isActive('product/create')); ?>">
                                <a href="<?php echo e(action('ProductController@create')); ?>">Add Product</a>
                            </li>
                            <li class="<?php echo e(isActive('categories')); ?>">
                                <a href="<?php echo e(action('CategoryController@index')); ?>">Add Category</a>
                            </li>
                            <li class="<?php echo e(isActive('parts')); ?>">
                                <a href="<?php echo e(action('PartsController@index')); ?>">Add Parts</a>
                            </li>
                            <li class="<?php echo e(isActive('productBrands')); ?>">
                                <a href="<?php echo e(action('ProductBrandController@index')); ?>">Add Product Brand</a>
                            </li>
                            <li class="<?php echo e(isActive('units')); ?>">
                                <a href="<?php echo e(action('UnitController@index')); ?>">Add Unit</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['stock*'])); ?>">
                        <a>
                            <i class="fa fa-stack-overflow" aria-hidden="true"></i>
                            <span>Stock</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('stocks')); ?>">
                                <a href="<?php echo e(action('StockController@index')); ?>">Stock List</a>
                            </li>
                        </ul>
                    </li>


                    <li class="nav-parent <?php echo e(isActive(['problem/create*','garageEntries*','garageEntry/create*','garageExit/create*','garageExit/create*','service/create*'])); ?>">
                        <a>
                            <i class="fa fa-wrench" aria-hidden="true"></i>
                            <span>Garage</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('garageEntry/create')); ?>">
                                <a href="<?php echo e(action('GarageEntryController@create')); ?>">Entry Vehicle</a>
                            </li>

                            <li class="<?php echo e(isActive('garageEntries')); ?>">
                                <a href="<?php echo e(action('GarageEntryController@index')); ?>">Vehicle List of Garage</a>
                            </li>

                            <li class="<?php echo e(isActive('problem/create')); ?>">
                                <a href="<?php echo e(action('ProblemController@create')); ?>">Vehicle Problem Entry</a>
                            </li>

                            <li class="<?php echo e(isActive('service/create')); ?>">
                                <a href="<?php echo e(action('ProblemController@create')); ?>">Vehicle Service Form</a>
                            </li>

                            <li class="<?php echo e(isActive('garageExit/create')); ?>">
                                <a href="<?php echo e(action('GarageExitController@create')); ?>">Exit Vehicle</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent">
                        <a>
                            <i class="fa fa-th-list" aria-hidden="true"></i>
                            <span>Inventory</span>
                        </a>
                        <ul class="nav nav-children">
                            <li>
                                <a href="">
                                    Add Product
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    Category
                                </a>

                            </li>
                            <li>
                                <a>
                                    Sub Category
                                </a>
                            </li>
                            <li>
                                <a>
                                    Brands
                                </a>

                            </li>
                            <li>
                                <a>
                                    Size
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-parent <?php echo e(isActive(['suppliers*','supplier/create*'])); ?>">
                        <a>
                            <i class="fa fa-briefcase" aria-hidden="true"></i>
                            <span>Suppliers</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('suppliers')); ?>">
                                <a href="<?php echo e(action('SupplierController@index')); ?>">Supplier list</a>
                            </li>
                            <li class="<?php echo e(isActive('supplier/create')); ?>">
                                <a href="<?php echo e(action('SupplierController@create')); ?>">Add Supplier</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['invoice*','addPurchase*'])); ?>">
                        <a>
                            <i class="fa fa-balance-scale" aria-hidden="true"></i>
                            <span>Purchase</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('invoices')); ?>">
                                <a href="<?php echo e(action('InvoiceController@index')); ?>">Purchase list</a>
                            </li>
                            <li class="<?php echo e(isActive('invoice/create')); ?>">
                                <a href="<?php echo e(action('InvoiceController@create')); ?>">Add Purchase</a>
                            </li>
                            
                                
                            
                        </ul>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['user*'])); ?>">
                        <a>
                            <i class="fa fa-users" aria-hidden="true"></i>
                            <span>User Management</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('users')); ?>">
                                <a href="<?php echo e(action('UserController@index')); ?>">Users</a>
                            </li>
                            <li class="<?php echo e(isActive('user/create')); ?>">
                                <a href="<?php echo e(action('UserController@create')); ?>">Add User</a>
                            </li>
                            <li class="<?php echo e(isActive('user/change')); ?>">
                                <a href="<?php echo e(action('UserController@changePassword')); ?>">Change Password</a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-parent <?php echo e(isActive(['companies*'])); ?>">
                        <a>
                            <i class="fa fa-users" aria-hidden="true"></i>
                            <span>Company Management</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('companies')); ?>">
                                <a href="<?php echo e(action('CompanyController@index')); ?>">Companies</a>
                            </li>
                            <li class="<?php echo e(isActive('company/create')); ?>">
                                <a href="<?php echo e(action('CompanyController@create')); ?>">Add Company</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
    </div>

</aside>
<!-- end: sidebar -->

