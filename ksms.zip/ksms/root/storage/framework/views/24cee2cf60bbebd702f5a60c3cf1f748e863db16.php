<?php $__env->startSection('title','Spare Parts'); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Spare Part</h2>
            <div class="right-wrapper pull-right">
                <ol class="breadcrumbs">
                    <li>
                        <a>
                            <i class="fa fa-home"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                </ol>
                <a class="sidebar-right-toggle" ><i class="fa fa-chevron-left"></i></a>
            </div>
        </header>
        <div class="row">
            <div class="col-md-12">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <!-- start: page -->
        <div class="row">
            <div class="col-xs-12">
                <section class="panel">
                    <header class="panel-heading">
                        <div class="panel-actions">
                            <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                        </div>
                        <h2 class="panel-title"> Add Part</h2>
                    </header>

                    <div class="panel-body">
                        <?php echo e(Form::open(['action'=>'SparePartController@store','method'=>'post','class'=>'form-horizontal'])); ?>


                        <div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('name', 'Parts Name:', ['class'=>'col-md-3 control-label'])); ?>

                            <div class="col-md-6">
                                <?php echo e(Form::text('name', null, ['class' => 'form-control','required'])); ?>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('part_id') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('part_id', 'Category Name:', ['class'=>'col-md-3 control-label'])); ?>

                            <div class="col-md-6">
                                <?php echo e(Form::select('part_id',$repository->parts(),null, ['class' => 'form-control populate','data-plugin-selectTwo','placeholder'=>'Parts','required'])); ?>

                                <?php if($errors->has('part_id')): ?>
                                    <span class="help-block">
                                    <strong><?php echo e($errors->first('part_id')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <?php echo e(Form::label('description','Description:',['class'=>'col-md-3 control-label'])); ?>

                            <div class="col-md-6">
                                <?php echo e(Form::textarea('description', null, ['class' => 'form-control'])); ?>

                                <?php if($errors->has('description')): ?>
                                    <span class="help-block">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-2 col-md-offset-3">
                                <?php echo e(Form::submit('Save',['class'=>'form-control btn btn-success'])); ?>

                            </div>
                            <div class="col-md-2">
                                
                                <?php echo e(Form::reset('Reset',['class'=>'form-control btn btn-warning'])); ?>

                            </div>
                            <div class="col-md-2">
                                
                                <a href="<?php echo e(URL::previous()); ?>" role="button" class="form-control btn btn-danger">Back</a>
                            </div>
                        </div>
                        <!-- ends-->
                        <?php echo e(Form::close()); ?>

                    </div>
                </section>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <section class="panel">
                    <header class="panel-heading">
                        <div class="panel-actions">
                            <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                        </div>
                        <h2 class="panel-title">Spare Parts</h2>
                    </header>

                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-condensed mb-none">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Part</th>
                                    <th>Description</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($part->id); ?></td>
                                        <td><?php echo e($part->name); ?></td>
                                        <td><?php echo e($part->part->name); ?></td>
                                        <td><?php echo e($part->description); ?></td>
                                        <td>
                                            <?php echo e(Form::open(['action'=>['SparePartController@destroy',$part->id],'method'=>'delete','onsubmit'=>'return confirmDelete()'])); ?>

                                            <a href="<?php echo e(action('SparePartController@edit',$part->id)); ?>" role="button" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                            <?php echo e(Form::submit('X',['class'=>'btn btn-danger'])); ?>

                                            <?php echo e(Form::close()); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>
            </div>
        </div>

    </section>
    <!-- end: page -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function confirmDelete(){
            var x = confirm('Are you sure you want to delete this record?');
            return !!x;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>