<div class="col-md-8">
    <?php if($errors->any): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

    <?php endif; ?>


    <div class="form-group">
        <label class="col-md-3 control-label" for="name">Name<span class="required">*</span>:</label>
        <div class="col-md-9">
            <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Company Name','required']); ?>

            <?php if($errors->has('name')): ?>
                <span class="help-block">
                <strong><?php echo e($errors->first('name')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-3 control-label" for="address">Address<span class="required">*</span>:</label>
        <div class="col-md-9">
            <?php echo Form::text('address',null,['class'=>'form-control','placeholder'=>'Company Address','required','required']); ?>

            <?php if($errors->has('address')): ?>
                <span class="help-block">
                <strong><?php echo e($errors->first('address')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="form-group<?php echo e($errors->has('country_id') ? ' has-error' : ''); ?>">
        <label class="col-md-3 control-label" for="country_id">Country<span class="required">*</span>:</label>
        <div class="col-md-9">
            <?php echo Form::select('country_id',$repository->countries(),null,['class'=>'form-control populate','data-plugin-selectTwo'=>'','id'=>'country','placeholder'=>'Select a Country','required']); ?>

            <?php if($errors->has('country_id')): ?>
                <span class="help-block">
                <strong><?php echo e($errors->first('country_id')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="form-group<?php echo e($errors->has('state_id') ? ' has-error' : ''); ?>">
        <label class="col-md-3 control-label" for="state_id">State<span class="required">*</span>:</label>
        <div class="col-md-9">
            <?php echo Form::select('state_id',$repository->states(),null,['class'=>'form-control populate','data-plugin-selectTwo'=>'','id'=>'state','placeholder'=>'Select a State','required']); ?>

            <?php if($errors->has('state_id')): ?>
                <span class="help-block">
                <strong><?php echo e($errors->first('state_id')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="form-group<?php echo e($errors->has('city_id') ? ' has-error' : ''); ?>">
        <label class="col-md-3 control-label" for="city_id">City<span class="required">*</span>:</label>
        <div class="col-md-9">
            <?php echo Form::select('city_id',$repository->cities(),null,['class'=>'form-control populate','data-plugin-selectTwo'=>'','id'=>'city','placeholder'=>'Select a City','required']); ?>

            <?php if($errors->has('city_id')): ?>
                <span class="help-block">
                <strong><?php echo e($errors->first('city_id')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
        <label class="col-md-3 control-label" for="phone">Phone<span class="required">*</span>:</label>
        <div class="col-md-9">
            <?php echo Form::text('phone',null,['class'=>'form-control','id'=>'inputDefault','placeholder'=>'Phone Number','required']); ?>

            <?php if($errors->has('phone')): ?>
                <span class="help-block">
                <strong><?php echo e($errors->first('phone')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>

    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <label class="col-md-3 control-label" for="email">Email:</label>
        <div class="col-md-9">
            <?php echo Form::text('email',null,['class'=>'form-control','id'=>'inputDefault','placeholder'=>'email@example.com as username']); ?>

            <?php if($errors->has('email')): ?>
                <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="form-group">
        <?php echo Form::label('Logo','',['class'=>'col-md-3 control-label']); ?>

        <br/>
        <div class="col-md-9">
            <img src="<?php echo e(asset('admin/images/companies')); ?>/<?php echo e($company->logo); ?>" id="blah" class="img-thumbnail" width="265" alt=""/>
            <?php echo Form::file('image',['onchange'=>'readURL(this)']); ?>

            <p>For better view upload image with resolution 100px*100px</p>
            <?php if($errors->has('logo')): ?>
                <span class="help-block">
                <strong><?php echo e($errors->first('logo')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>

    <div class="form-group">
        <?php echo Form::label('Favicon','',['class'=>'col-md-3 control-label']); ?>

        <br/>
        <div class="col-md-9">
            <img src="<?php echo e(asset('admin/images/companies')); ?>/<?php echo e($company->favicon); ?>" id="blah" class="img-thumbnail" width="100" alt=""/>
            <?php echo Form::file('favicon',['onchange'=>'readURL(this)']); ?>

            <p>For better view upload image with resolution 50px*50px</p>
            <?php if($errors->has('favicon')): ?>
                <span class="help-block">
                <strong><?php echo e($errors->first('favicon')); ?></strong>
            </span>
            <?php endif; ?>
        </div>
    </div>

</div>

<div class="col-md-12 text-center">
    <hr/>
    <h3>Login Password for Admin</h3>
    <hr/>
</div>

<!--User Starts-->

<div class="form-group <?php echo e($errors->has('password')?'has-error':''); ?>">
    <label class="col-md-2 control-label">Password:</label>
    <div class="col-md-6">
        <?php echo e(Form::password('password',['class' => 'form-control','placeholder'=>'Password','required'])); ?>

        <?php if($errors->has('password')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('password')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<div class="form-group <?php echo e($errors->has('password_confirmation')?'has-error':''); ?>">
    <label class="col-md-2 control-label">Confirm Password:</label>
    <div class="col-md-6">
        <?php echo e(Form::password('password_confirmation',['class' => 'form-control','placeholder'=>'Confirm Password','required'])); ?>

        <?php if($errors->has('password_confirmation')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('password_confirmation')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>


<!--User Ends -->

<div class="form-group text-center row">
    <div class="col-md-12">
        <?php echo Form::submit($submitButtonText,['class'=>'btn btn-success']); ?>

        <?php echo Form::reset('Reset',['class'=>'btn btn-warning']); ?>

        <a href="<?php echo e(URL::previous()); ?>" role="button" class="btn btn-danger">Cancel</a>
    </div>
</div>

<?php $__env->startSection('script'); ?>
    
        
         
         
        
            
            
            
            
                
                
                
            

                
                
                
                
            
        
    

    
        
         
         
        
            
            
            
            
                
                
                
            

                
                
                
                
            
        
    

    
        
         
         
        
            
            
            
            
                
            
            
                
            
        
    

    
        
         
         
        
            
            
                
                
                    
                    
                    
                
                    
                    
                    
                        
                        
                        
                    
                        
                    
                
            
        
    

    
        
            
             
             
            
                
            
            
                
            
        
    

    <script>
        /**
         * Display selected image on form before store or updating storage
         * Created by: smartrahat on 05.12.2016 02:16PM
         * @param  input
         */
        function readURL(input) {
            if (input.files && input.files[0]) {

                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#blah').attr('src', e.target.result).width(265).height(260);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>

<?php $__env->stopSection(); ?>