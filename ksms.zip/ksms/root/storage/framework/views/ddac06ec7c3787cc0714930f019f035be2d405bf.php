<!-- Supplier Name Starts-->
<div class="form-group <?php echo e($errors->has('supplier_name')? 'has-error':''); ?>">
    <?php echo e(Form::label('supplier_name', 'Supplier Name:', array('class'=>'col-md-3 control-label'))); ?>

    
    <div class="col-md-6">
        <?php echo e(Form::text('supplier_name', null, array('class' => 'form-control'))); ?>

        <?php if($errors->has('supplier_name')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('supplier_name')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Supplier name ends-->

<!-- Supplier Contact person Name Starts-->
<div class="form-group  <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('name', 'Contact Person:', array('class'=>'col-md-3 control-label'))); ?>

    
    <div class="col-md-6">
        <?php echo e(Form::text('name', null, array('class' => 'form-control'))); ?>

        <?php if($errors->has('name')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('name')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Supplier Contact person Name ends-->

<!-- Address Starts-->
<div class="form-group  <?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('address', 'Address:', array('class'=>'col-md-3 control-label'))); ?>

    
    <div class="col-md-6">
        <?php echo e(Form::text('address', null, array('class' => 'form-control'))); ?>

        <?php if($errors->has('address')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('address')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Address ends-->

<!-- mobile Number Starts-->
<div class="form-group  <?php echo e($errors->has('mobile') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('mobile', 'Mobile No.:', array('class'=>'col-md-3 control-label'))); ?>

    
    <div class="col-md-6">
        <?php echo e(Form::text('mobile',null, array('class' => 'form-control'))); ?>

        <?php if($errors->has('mobile')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('mobile')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- mobile Number ends-->

<!-- Email Starts-->
<div class="form-group  <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('email', 'E-mail:', array('class'=>'col-md-3 control-label'))); ?>

    
    <div class="col-md-6">
        <?php echo e(Form::text('email',null, array('class' => 'form-control'))); ?>

        <?php if($errors->has('email')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('email')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Email ends-->

<div class="form-group">
    <div class="col-md-2 col-md-offset-3">
        <?php echo e(Form::submit($submitButtonText,['class'=>'form-control btn btn-success'])); ?>

    </div>
    <div class="col-md-2">
        <?php echo e(Form::reset('Reset',['class'=>'form-control btn btn-warning'])); ?>

    </div>
    <div class="col-md-2">
        <a href="<?php echo e(URL::previous()); ?>" role="button" class="form-control btn btn-danger">Back</a>
    </div>
</div>
<!-- ends -->