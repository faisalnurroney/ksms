<?php $__env->startSection('title','Rotation List'); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">

        <header class="page-header no-print">
            <h2>Program Report</h2>
            <div class="right-wrapper pull-right">
                <ol class="breadcrumbs">
                    <li>
                        <a>
                            <i class="fa fa-home"></i>
                        </a>
                    </li>
                    <li><span>Dashboard</span></li>
                </ol>
                <a class="sidebar-right-toggle" ><i class="fa fa-chevron-left"></i></a>
            </div>
        </header>

        <section class="panel">
            <header class="panel-heading">
                <div class="panel-actions">
                    <a href="javascript:window.print()"><i class="fa fa-print"></i></a>
                    <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                </div>
                <h2 class="panel-title">Program Report</h2>
            </header>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-condensed mb-none">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Date</th>
                            <th>Truck No</th>
                            <th>Driver Name</th>
                            <th>Party Name</th>
                            <th>Party Address</th>
                            <th>Contact Person</th>
                            <th>Mobile</th>
                            <th>Loading Point</th>
                            <th>Unloading Point</th>
                            <th>Empty Container</th>
                            <th>Product<br>(Qty)</th>
                            <th>(Rent)<br>Adv.<br>
                                Due<br>
                                Total </th>
                            <th>Fuel (Ltr)<br>Cost</th>
                            <th>Cont. Charge<br>Labour (load/<br>unload)</th>
                            <th>(Allowance)<br>Driver <br>Helper</th>
                            <th>Toll<br>Bridge<br>Scale</th>
                            <th>Wheel Main</th>
                            <th>Guard/<br>Dona<br>tion</th>
                            <th>Other</th>
                            <th>Driver Advance</th>
                            <th>Nit Received/<br>Paid</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $tripCosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tripCost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($tripCost->id); ?></td>
                                <td><?php echo e($tripCost->program->date); ?></td>
                                <td><?php echo e($tripCost->program->vehicle->vehicleNo); ?></td>
                                <td><?php echo e($tripCost->program->driver->name); ?></td>
                                <td><?php echo e($tripCost->program->party->name); ?></td>
                                <td><?php echo e($tripCost->program->party->address); ?></td>
                                <td><?php echo e($tripCost->program->party->contact_person); ?></td>
                                <td><?php echo e($tripCost->program->vehicle->mobile); ?></td>
                                <td><?php echo e($tripCost->program->trip->loading); ?></td>
                                <td><?php echo e($tripCost->program->trip->unloading); ?></td>
                                <td><?php echo e($tripCost->program->trip->emp_container); ?></td>
                                <td><?php echo e($tripCost->program->trip->product); ?></td>
                                <td class="text-right"><?php echo e(number_format($tripCost->program->adv_rent)); ?>/-<br>
                                    <?php echo e(number_format($tripCost->program->due_rent)); ?>/-<br>
                                    <?php echo e(number_format($tripCost->program->rent)); ?>/-</td>
                                <td class="text-right"><?php echo e($tripCost->program->trip->fuel); ?><br>
                                    <?php echo e(number_format($tripCost->fuel_cost)); ?>/-</td>
                                <td class="text-right"><?php echo e(number_format($tripCost->program->tripCost->container)); ?>/-<br><?php echo e(number_format($tripCost->labour)); ?>/-</td>
                                <td class="text-right"><?php echo e(number_format($tripCost->driver_allow)); ?>/-<br>
                                    <?php echo e(number_format($tripCost->helper_allow)); ?>/-</td>
                                <td class="text-right"><?php echo e(number_format($tripCost->toll)); ?>/-<br>
                                    <?php echo e(number_format($tripCost->bridge)); ?>/-<br>
                                    <?php echo e(number_format($tripCost->scale)); ?>/-<br></td>
                                <td class="text-right"><?php echo e(number_format($tripCost->wheel)); ?>/-</td>
                                <td class="text-right"><?php echo e(number_format($tripCost->donation)); ?>/-</td>
                                <td class="text-right"><?php echo e(number_format($tripCost->other)); ?>/-</td>
                                <td class="text-right"><?php echo e(number_format($tripCost->program->trip->driver_adv)); ?>/-</td>
                                <td class="text-right"></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div><br>
            </div>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function confirmDelete(){
            var x = confirm('Are you sure you want to delete this record?');
            return !!x;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>