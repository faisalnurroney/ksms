<!-- start: sidebar -->
<aside id="sidebar-left" class="sidebar-left no-print">
    <div class="sidebar-header">
        <div class="sidebar-title">
            Navigation
        </div>
        <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
            <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
        </div>
    </div>
    <div class="nano">
        <div class="nano-content">
            <nav id="menu" class="nav-main" role="navigation">
                <ul class="nav nav-main">
                    <li class="<?php echo e(isActive('/')); ?>">
                        <a href="<?php echo e(url('/')); ?>">
                            <i class="fa fa-tachometer" aria-hidden="true"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['programs*'])); ?>">
                        <a>
                            <i class="fa fa-ship" aria-hidden="true"></i>
                            <span>Parent</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('programs')); ?>">
                                <a href="<?php echo e(action('ProgramController@index')); ?>">Child</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['user*'])); ?>">
                        <a>
                            <i class="fa fa-users" aria-hidden="true"></i>
                            <span>User Management</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('users')); ?>">
                                <a href="<?php echo e(action('UserController@index')); ?>">Users</a>
                            </li>
                            <li class="<?php echo e(isActive('user/create')); ?>">
                                <a href="<?php echo e(action('UserController@create')); ?>">Add User</a>
                            </li>
                            <li class="<?php echo e(isActive('user/change')); ?>">
                                <a href="<?php echo e(action('UserController@changePassword')); ?>">Change Password</a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-parent <?php echo e(isActive(['companies*'])); ?>">
                        <a>
                            <i class="fa fa-users" aria-hidden="true"></i>
                            <span>Company Management</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('companies')); ?>">
                                <a href="<?php echo e(action('CompanyController@index')); ?>">Companies</a>
                            </li>
                            <li class="<?php echo e(isActive('company/create')); ?>">
                                <a href="<?php echo e(action('CompanyController@create')); ?>">Add Company</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
    </div>

</aside>
<!-- end: sidebar -->

