
<!-- User Starts-->
<div class="form-group <?php echo e($errors->has('employee_id')? 'has-error':''); ?>">
    <?php echo e(Form::label('employee_id', 'User Name:', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('employee_id',$repository->employees(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select User'])); ?>

        <?php if($errors->has('employee_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('employee_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- User ends-->
<!-- Vehicle Checkbox Starts-->
<div class="form-group">

    <div class="panel-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-condensed mb-none">
                <thead>
                <tr>
                    <th class="text-center" colspan="2">ID</th>
                    <th class="text-center">Vehicle Number</th>
                    <th class="text-center">Manager Name</th>
                    <th class="text-center">Owner Name</th>
                    <th class="text-center">Status</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e(Form::checkbox('vehicles[]', $vehicle->id, null, ['class' => 'field'])); ?></td>
                        <td class="text-center"><?php echo e($vehicle->id); ?></td>
                        <td class="text-center"><?php echo e($vehicle->vehicleNo); ?></td>
                        <td class="text-center"><?php echo e($vehicle->employee->name); ?></td>
                        <td><?php echo e($vehicle->owner->name); ?></td>
                        <td><?php echo e($vehicle->status->name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!--Submit button -->
<div class="form-group">
    <div class="col-md-2 col-md-offset-3">
        <?php echo e(Form::submit($submitButtonText,['class'=>'form-control btn btn-success',$vehicle->id])); ?>

    </div>
    <div class="col-md-2">
        <?php echo e(Form::reset('Reset',['class'=>'form-control btn btn-warning'])); ?>

    </div>
    <div class="col-md-2">
        <a href="<?php echo e(URL::previous()); ?>" role="button" class="form-control btn btn-danger">Cancel</a>
    </div>
</div>
<!-- ends-->