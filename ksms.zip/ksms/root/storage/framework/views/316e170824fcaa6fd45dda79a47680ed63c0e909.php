
<!--Date starts-->
<div class="form-group <?php echo e($errors->has('date')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Program Date:</label>
    <div class="col-md-6">
        <div class="input-group">
                <span class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                </span>
            <?php echo e(Form::text('date', null, array('class' => 'form-control','data-plugin-datepicker data-date-format="yyyy-mm-dd"' ))); ?>

        </div>
        <?php if($errors->has('date')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('date')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>

<!--Date ends-->

<!-- Serial Starts-->
<div class="form-group <?php echo e($errors->has('serial')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Serial Number:</label>
    <div class="col-md-6">
        <?php echo e(Form::text('serial',null, array('class' => 'form-control'))); ?>

        <?php if($errors->has('serial')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('serial')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Serial ends-->

<!-- party start-->
<div class="form-group <?php echo e($errors->has('party_id')?'has-error':''); ?>">
    <?php echo e(Form::label('party_id', 'Party Name:', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('party_id',$repository->parties(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select Party'])); ?>

        <?php if($errors->has('party_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('party_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- party ends-->


<!-- Employee start-->
<div class="form-group <?php echo e($errors->has('employee_id')?'has-error':''); ?>">
    <?php echo e(Form::label('employee_id', 'SR Name:', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('employee_id',$repository->employees(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select SR'])); ?>

        <?php if($errors->has('employee_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('employee_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Employee ends-->

<!-- Option Starts-->
<div class="form-group">
    <?php echo e(Form::label('option', 'Rent Option:', ['class'=>'col-md-3 control-label'])); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('option',['Fixed','On Product Weight'],null,['class'=>'form-control populate','id'=>'option','data-plugin-selectTwo','placeholder'=>'Select Rent Option'])); ?>

    </div>
</div>
<!-- Option ends-->

<!-- Weight Starts-->
<div class="form-group" id='weight_div' hidden="hidden">
    <label class="col-md-3 control-label">Weight (KG/Tons):</label>
    <div class="col-md-6">
        <?php echo e(Form::text('weight',null, array('class' => 'form-control','id'=>'weight'))); ?>

    </div>
</div>
<!-- Weight ends-->

<!-- Rate Starts-->
<div class="form-group" id='rate_div' hidden="hidden">
    <label class="col-md-3 control-label">Rate (tk):</label>
    <div class="col-md-6">
        <?php echo e(Form::text('rate',null, array('class' => 'form-control','id'=>'rate'))); ?>

    </div>
</div>
<!-- Rate ends-->

<!-- Total Rent Starts-->
<div class="form-group <?php echo e($errors->has('rent')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Total Rent:</label>
    <div class="col-md-6">
        <?php echo e(Form::text('rent',null, array('class' => 'form-control','id'=>'rent'))); ?>

        <?php if($errors->has('rent')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('rent')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Total Rent ends-->

<!-- Advance Rent Starts-->
<div class="form-group <?php echo e($errors->has('adv_rent')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Advance Rent:</label>
    <div class="col-md-6">
        <?php echo e(Form::text('adv_rent',null, array('class' => 'form-control','id'=>'adv_rent'))); ?>

        <?php if($errors->has('adv_rent')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('adv_rent')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Advance Rent ends-->

<!-- Due Rent Starts-->
<div class="form-group <?php echo e($errors->has('due_rent')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Due Rent:</label>
    <div class="col-md-6">
        <?php echo e(Form::text('due_rent',null, ['class' => 'form-control','id'=>'due_rent','readonly'])); ?>

        <?php if($errors->has('due_rent')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('due_rent')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Due Rent ends-->

<div class="col-md-12">
    <hr>
</div>

<!--Trips parts-->
<!--DOOR OPEN-->
<div id="door">
    <?php if(count($trips) > 0): ?>
        <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="text-center" id="product<?php echo e($num); ?>">
                <div class="col-md-11">
                    <div class="col-md-12 col-md-offset-1">
                        <div class=" col-md-2">
                            <label class="control-label" for="driver_id">Driver</label>
                            <div class="">
                                <?php echo Form::select('driver_id'.$num,$repository->drivers(),$trip->id,['id'=>'driver_id'.$num,'class'=>'form-control','required','placeholder'=>'Select a driver']); ?>

                            </div>
                        </div>
                        <div class="col-md-2">
                            <label class="control-label" for="vehicle_id">Vehicle</label>
                            <div class="">
                                <?php echo Form::select('vehicle_id'.$num,$repository->vehicles(),$trip->id,['id'=>'vehicle_id'.$num,'class'=>'form-control','required','placeholder'=>'Select a vehicle']); ?>

                            </div>
                        </div>

                        <!-- Driver Advance Starts-->
                        <div class="col-md-2 <?php echo e($errors->has('driver_adv')?'has-error':''); ?>">
                            <label class="control-label text-left" for="driver_adv">Driver Advance</label>
                            <?php echo e(Form::text('driver_adv'.$num, $trip->driver_adv, ['class' => 'form-control','id'=>'driver_adv'.$num])); ?>

                            <?php if($errors->has('driver_adv')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('driver_adv')); ?></strong></span>
                            <?php endif; ?>
                        </div>
                        <!-- Driver Advance ends-->

                        <!-- Driver Advance Fixed Starts-->

                        <div class="col-md-2 <?php echo e($errors->has('d_a_fix')?'has-error':''); ?>">
                            <label class="control-label text-center" for="d_a_fix">Drv Adv (Fixed)</label>
                            <?php echo e(Form::text('d_a_fix'.$num, $trip->d_a_fix, array('class' => 'form-control','id'=>'d_a_fix'.$num))); ?>

                            <?php if($errors->has('d_a_fix')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('d_a_fix')); ?></strong></span>
                            <?php endif; ?>
                        </div>

                        <!-- Driver Advance Fixed ends-->

                        <!-- Driver Extra Given Starts-->
                        <div class="col-md-2 <?php echo e($errors->has('extra_adv')?'has-error':''); ?>">
                            <label class="control-label text-left" for="extra_adv">Extra Advance</label>
                            <?php echo e(Form::text('extra_adv'.$num, $trip->extra_adv, array('class' => 'form-control','id'=>'extra_adv'.$num,'readonly'))); ?>

                            <?php if($errors->has('extra_adv')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('extra_adv')); ?></strong></span>
                            <?php endif; ?>
                        </div>
                        <!-- Driver Extra Given ends-->
                        
                        
                    </div>
                    <div class="col-md-12 col-md-offset-1">
                        <!-- Loading Starts-->
                        <div class="col-md-2 <?php echo e($errors->has('loading')?'has-error':''); ?>">
                            <label class="control-label text-center" for="loading">Loading Point</label>
                            <?php echo e(Form::text('loading'.$num,$trip->loading, array('class' => 'form-control','id'=>'loading'.$num))); ?>

                            <?php if($errors->has('loading')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('loading')); ?></strong></span>
                            <?php endif; ?>
                        </div>
                        <!-- Loading ends-->

                        <!-- Unloading Starts-->
                        <div class="col-md-2 <?php echo e($errors->has('unloading')?'has-error':''); ?>">
                            <label class="control-label text-center" for="unloading">Unloading Point</label>
                            <?php echo e(Form::text('unloading'.$num,$trip->unloading, array('class' => 'form-control','id'=>'unloading'.$num))); ?>

                            <?php if($errors->has('unloading')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('unloading')); ?></strong></span>
                            <?php endif; ?>
                        </div>
                        <!-- Unloading ends-->

                        <!-- Product Details Starts-->
                        <div class="col-md-2 <?php echo e($errors->has('product')?'has-error':''); ?>">
                            <label class="control-label text-center" for="product">Product Details</label>
                            <?php echo e(Form::text('product'.$num, $trip->product, array('class' => 'form-control','id'=>'product'.$num))); ?>

                            <?php if($errors->has('product')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('product')); ?></strong></span>
                            <?php endif; ?>
                        </div>
                        <!-- Product Details ends-->

                        <!-- Empty Container Starts-->
                        <div class="col-md-2 <?php echo e($errors->has('emp_container')?'has-error':''); ?>">
                            <label class="control-label text-center" for="emp_container">Empty Container</label>
                            <?php echo e(Form::text('emp_container'.$num, $trip->emp_container, array('class' => 'form-control','id'=>'emp_container'.$num))); ?>

                            <?php if($errors->has('emp_container')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('emp_container')); ?></strong></span>
                            <?php endif; ?>
                        </div>
                        <!-- Empty Container ends-->

                        <!-- Fuel Starts-->
                        <div class="col-md-2 <?php echo e($errors->has('fuel')?'has-error':''); ?>">
                            <label class="control-label text-center" for="loading">Fuel Qty (Ltr)</label>
                            <?php echo e(Form::text('fuel'.$num, $trip->fuel, array('class' => 'form-control','id'=>'fuel'.$num))); ?>

                            <?php if($errors->has('fuel')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('fuel')); ?></strong></span>
                            <?php endif; ?>
                        </div>
                        <!-- Fuel ends-->
                    </div>
                </div>
                <!--REMOVE BUTTON START-->
                <div class="col-md-1 col-md-pull-1" >
                    <div class="form-group " style="padding-top: 29px;">
                        <button type="button" class="btn btn-danger remove-btn" style="display: inline-block;">Remove</button>
                    </div>
                </div>
                <div class="col-md-12">
                    <hr>
                </div>
                <!--REMOVE BUTTON END-->

            </div>
            <div style="display:none">
                <?php echo e($num++); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <div class="text-center" id="product1">
        <div class="col-md-11">
            <div class="col-md-12 col-md-offset-1">
                <div class=" col-md-2">
                    <label class="control-label" for="driver_id">Driver</label>
                    <div class="">
                        <?php echo Form::select('driver_id1',$repository->drivers(),null,['id'=>'driver_id1','class'=>'form-control','required','placeholder'=>'Select a driver']); ?>

                    </div>
                </div>
                <div class="col-md-2">
                    <label class="control-label" for="vehicle_id">Vehicle</label>
                    <div class="">
                        <?php echo Form::select('vehicle_id1',$repository->vehicles(),null,['id'=>'vehicle_id1','class'=>'form-control','required','placeholder'=>'Select a vehicle']); ?>

                    </div>
                </div>

                <!-- Driver Advance Starts-->
                <div class="col-md-2 <?php echo e($errors->has('driver_adv1')?'has-error':''); ?>">
                    <label class="control-label text-left" for="driver_adv">Driver Advance</label>
                    <?php echo e(Form::text('driver_adv1', null, ['class' => 'form-control','id'=>'driver_adv1'])); ?>

                    <?php if($errors->has('driver_adv1')): ?>
                        <span class="help-block"><strong><?php echo e($errors->first('driver_adv1')); ?></strong></span>
                    <?php endif; ?>
                </div>
                <!-- Driver Advance ends-->

                <!-- Driver Advance Fixed Starts-->

                <div class="col-md-2 <?php echo e($errors->has('d_a_fix1')?'has-error':''); ?>">
                    <label class="control-label text-center" for="d_a_fix">Drv Adv (Fixed)</label>
                    <?php echo e(Form::text('d_a_fix1', null, array('class' => 'form-control','id'=>'d_a_fix1'))); ?>

                    <?php if($errors->has('d_a_fix1')): ?>
                        <span class="help-block"><strong><?php echo e($errors->first('d_a_fix1')); ?></strong></span>
                    <?php endif; ?>
                </div>

                <!-- Driver Advance Fixed ends-->

                <!-- Driver Extra Given Starts-->
                <div class="col-md-2 <?php echo e($errors->has('extra_adv1')?'has-error':''); ?>">
                    <label class="control-label text-left" for="extra_adv">Extra Advance</label>
                    <?php echo e(Form::text('extra_adv1', null, array('class' => 'form-control','id'=>'extra_adv1','readonly'))); ?>

                    <?php if($errors->has('extra_adv1')): ?>
                        <span class="help-block"><strong><?php echo e($errors->first('extra_adv1')); ?></strong></span>
                    <?php endif; ?>
                </div>
                <!-- Driver Extra Given ends-->
                
                
               </div>
             <div class="col-md-12 col-md-offset-1">
            <!-- Loading Starts-->
                <div class="col-md-2 <?php echo e($errors->has('loading1')?'has-error':''); ?>">
                    <label class="control-label text-center" for="loading1">Loading Point</label>
                    <?php echo e(Form::text('loading1', null, array('class' => 'form-control','id'=>'loading1'))); ?>

                    <?php if($errors->has('loading1')): ?>
                        <span class="help-block"><strong><?php echo e($errors->first('loading1')); ?></strong></span>
                    <?php endif; ?>
                </div>
                <!-- Loading ends-->

                <!-- Unloading Starts-->
                <div class="col-md-2 <?php echo e($errors->has('unloading1')?'has-error':''); ?>">
                    <label class="control-label text-center" for="unloading1">Unloading Point</label>
                    <?php echo e(Form::text('unloading1', null, array('class' => 'form-control','id'=>'unloading1'))); ?>

                    <?php if($errors->has('unloading1')): ?>
                        <span class="help-block"><strong><?php echo e($errors->first('unloading1')); ?></strong></span>
                    <?php endif; ?>
                </div>
                <!-- Unloading ends-->

                <!-- Product Details Starts-->
                <div class="col-md-2 <?php echo e($errors->has('product')?'has-error':''); ?>">
                    <label class="control-label text-center" for="product1">Product Details</label>
                    <?php echo e(Form::text('product1', null, array('class' => 'form-control','id'=>'product1'))); ?>

                    <?php if($errors->has('product1')): ?>
                        <span class="help-block"><strong><?php echo e($errors->first('product1')); ?></strong></span>
                    <?php endif; ?>
                </div>
                <!-- Product Details ends-->

                <!-- Empty Container Starts-->
                <div class="col-md-2 <?php echo e($errors->has('emp_container1')?'has-error':''); ?>">
                    <label class="control-label text-center" for="emp_container">Empty Container</label>
                    <?php echo e(Form::text('emp_container1', null, array('class' => 'form-control','id'=>'emp_container1'))); ?>

                    <?php if($errors->has('emp_container1')): ?>
                        <span class="help-block"><strong><?php echo e($errors->first('emp_container')); ?></strong></span>
                    <?php endif; ?>
                </div>
                <!-- Empty Container ends-->

                <!-- Fuel Starts-->
                <div class="col-md-2 <?php echo e($errors->has('fuel1')?'has-error':''); ?>">
                    <label class="control-label text-center" for="fuel">Fuel Qty (Ltr)</label>
                    <?php echo e(Form::text('fuel1', null, array('class' => 'form-control','id'=>'fuel1'))); ?>

                    <?php if($errors->has('fuel1')): ?>
                        <span class="help-block"><strong><?php echo e($errors->first('fuel1')); ?></strong></span>
                    <?php endif; ?>
                </div>
                <!-- Fuel ends-->
            </div>
        </div>
        <!--REMOVE BUTTON START-->
        <div class="col-md-1 col-md-pull-1" >
            <div class="form-group " style="padding-top: 29px;">
                <button type="button" class="btn btn-danger remove-btn" style="display: inline-block;">Remove</button>
            </div>
        </div>
        <div class="col-md-12">
            <hr>
        </div>
        <!--REMOVE BUTTON END-->

    </div>
    <?php endif; ?>
</div>
<!--DOOR CLOSE-->

<div class="col-md-12 col-md-offset-1">
    <div class="form-group col-md-2 ">
        <button class="btn btn-primary" onclick="addRow()" type="button">Add more...</button>
    </div>
</div>

<!--Submit button -->
<div class="form-group">
    <div class="col-md-2 col-md-offset-3">
        <?php echo e(Form::submit($submitButtonText,['class'=>'form-control btn btn-success'])); ?>

    </div>
    <div class="col-md-2">
        <?php echo e(Form::reset('Reset',['class'=>'form-control btn btn-warning'])); ?>

    </div>
    <div class="col-md-2">
        <a href="<?php echo e(URL::previous()); ?>" role="button" class="form-control btn btn-danger">Back</a>
    </div>
</div>
<!-- ends-->

<?php $__env->startSection('script'); ?>
    <script>
        // Add new row
        function addRow(){
            // get the last DIV which ID starts with ^= "product"
            var $div = $('div[id^="product"]:last');

            // Read the Number from that DIV's ID (i.e: 3 from "product3")
            // And increment that number by 1
            var num = parseInt( $div.prop("id").match(/\d+/g), 10 ) +1;

            // Clone it and assign the new ID (i.e: from num 4 to ID "product4")
            var $klon = $div.clone().prop('id', 'product'+num);

            $('select[id^="driver_id"]:last').prop('id','driver_id'+num).prop('name','driver_id'+num);
            $('select[id^="vehicle_id"]:last').prop('id','vehicle_id'+num).prop('name','vehicle_id'+num);
            $('input[id^="driver_adv"]:last').prop('id','driver_adv'+num).prop('name','driver_adv'+num);
            $('input[id^="d_a_fix"]:last').prop('id','d_a_fix'+num).prop('name','d_a_fix'+num);
            $('input[id^="extra_adv"]:last').prop('id','extra_adv'+num).prop('name','extra_adv'+num);
            $('input[id^="loading"]:last').prop('id','loading'+num).prop('name','loading'+num);
            $('input[id^="unloading"]:last').prop('id','unloading'+num).prop('name','unloading'+num);
            $('input[id^="product"]:last').prop('id','product'+num).prop('name','product'+num);
            $('input[id^="emp_container"]:last').prop('id','emp_container'+num).prop('name','emp_container'+num);
            $('input[id^="fuel"]:last').prop('id','fuel'+num).prop('name','fuel'+num);

            // >>> Append $klon wherever you want
            $klon.appendTo($("#door"));
        }
    </script>
    <script>
        // remove "remove button" if only one row left
        $(document).on('click ready',function(){
            if($('div[id^="product"]').length > 1){
                $(".remove-btn").show()
            }else{
                $(".remove-btn").hide()
            }
        });
    </script>
    <script>
        // remove program's row
        setInterval(function(){
            $(".remove-btn").click(function(){
                var $div = $('div[id^="product"]');
                if($div.length > 1){
                    $(this).closest($div).remove()
                }
            });
        },1000)

    </script>
    <script>
        //        $(document).ready( function() {
        $('#option').bind('change', function () {
            if( $('#option').val() == 1) {
                $('#rate_div').show();
                $('#weight_div').show();
                $('#rate').removeAttr('disabled');
                $('#weight').removeAttr('disabled');
            }else{
                $('#rate_div').hide();
                $('#weight_div').hide();
                $('#weight').val(0);
                $('#rate').val(0);
                $('#rate').attr('disabled','disabled');
                $('#weight').attr('disabled','disabled');
            }
        });
        //        });
    </script>
    <script>
        $(document).keyup(function () {
            var weight = $('#weight').val();
            var rate = $('#rate').val();
            if(weight>0 && rate>0){
                $('#rent').val(parseFloat(weight)*parseFloat(rate));
            }
        })
    </script>

    <script>
        $(document).keyup(function () {
            var rent = $('#rent').val();
            var advance = $('#adv_rent').val();
            $('#due_rent').val(parseFloat(rent) - parseFloat(advance));
        })
    </script>

    
    
    
    
    
    
    
    <script>
        $(document).keyup(function () {
            var $div = $('div[id^="product"]:last');
            var num = parseInt( $div.prop("id").match(/\d+/g), 10 ) +1;

            for(var i=1;i<num;i++){
                var a = $("#product"+i+" input[id^='driver_adv']").val();
                var b = $("#product"+i+" input[id^='d_a_fix']").val();
                var c =$("#product"+i+" input[id^='extra_adv']").val(parseInt(a)-parseInt(b));
            }
        })
    </script>
<?php $__env->stopSection(); ?>