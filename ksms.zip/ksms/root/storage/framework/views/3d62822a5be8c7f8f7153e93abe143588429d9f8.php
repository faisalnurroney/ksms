<!--Date starts-->
<div class="form-group <?php echo e($errors->has('date')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Purchase Date:</label>
    <div class="col-md-6">
        <div class="input-group">
                <span class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                </span>
            <?php echo e(Form::text('date', null, array('class' => 'form-control','data-plugin-datepicker data-date-format="yyyy-mm-dd"' ))); ?>

        </div>
        <?php if($errors->has('date')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('date')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>

<!-- Buyer Name Starts-->
<div class="form-group <?php echo e($errors->has('employee_id')?'has-error':''); ?>">
    <?php echo e(Form::label('employee_id', 'Buyer Name:', array('class'=>'col-md-3 control-label'))); ?>

    
    <div class="col-md-6">
        <?php echo e(Form::select('employee_id',$repository->employees(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select Supplier'])); ?>

        <?php if($errors->has('employee_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('employee_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Supplier Name ends-->



<!-- Supplier Name Starts-->
<div class="form-group <?php echo e($errors->has('supplier_id')?'has-error':''); ?>">
    <?php echo e(Form::label('supplier_id', 'Shop Name:', array('class'=>'col-md-3 control-label'))); ?>

    
    <div class="col-md-6">
        <?php echo e(Form::select('supplier_id',$repository->suppliers(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select Supplier'])); ?>

        <?php if($errors->has('supplier_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('supplier_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Supplier Name ends-->

<!-- Voucher Starts-->
<div class="form-group <?php echo e($errors->has('voucher')?'has-error':''); ?>">
    <?php echo e(Form::label('voucher', 'Voucher No:', array('class'=>'col-md-3 control-label'))); ?>

    
    <div class="col-md-6">
        <?php echo e(Form::text('voucher',null, array('class' => 'form-control'))); ?>

        <?php if($errors->has('voucher')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('voucher')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Voucher ends-->

<!-- Total Starts-->
<div class="form-group <?php echo e($errors->has('total')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Total:</label>
    <div class="col-md-6">
        <?php echo e(Form::text('total',null, array('class' => 'form-control','id'=>'total','readonly'))); ?>

        <?php if($errors->has('total')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('total')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Total ends-->

<!-- Advance Starts-->
<div class="form-group <?php echo e($errors->has('advance')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Advance:</label>
    <div class="col-md-6">
        <?php echo e(Form::text('advance',null, array('class' => 'form-control','id'=>'advance'))); ?>

        <?php if($errors->has('advance')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('advance')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Advance ends-->

<!-- Due Starts-->
<div class="form-group <?php echo e($errors->has('due')?'has-error':''); ?>">
    <label class="col-md-3 control-label">Due:</label>
    <div class="col-md-6">
        <?php echo e(Form::text('due',null, ['class' => 'form-control','id'=>'due','readonly'])); ?>

        <?php if($errors->has('due')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('due')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Due ends-->




<div class="col-md-12">
    <hr>
</div>

<!--Product Details Start-->
<!--DOOR OPEN-->
<div id="door">
    <?php if(count($products) > 0): ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="text-center" id="product<?php echo e($num); ?>">
                <div class="col-md-10">
                    <div class="col-md-12">
                        <div class=" col-md-3">
                            <label class="control-label" for="product_id">Product Name</label>
                            <div class="">
                                <?php echo Form::select('product_id',$repository->products(),$product->product_id,['id'=>'product_id','class'=>'form-control','required','placeholder'=>'Select a product']); ?>

                            </div>
                        </div>
                        <!-- Quantity Starts-->
                        <div class="col-md-3 <?php echo e($errors->has('quantity')?'has-error':''); ?>">
                            <label class="control-label text-left" for="quantity">Quantity</label>
                            <?php echo e(Form::text('quantity', $product->quantity, ['class' => 'form-control','id'=>'quantity'])); ?>

                            <?php if($errors->has('quantity')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('quantity')); ?></strong></span>
                            <?php endif; ?>
                        </div>
                        <!-- Quantity ends-->

                        <!-- Rate Starts-->
                        <div class="col-md-3 <?php echo e($errors->has('rate')?'has-error':''); ?>">
                            <label class="control-label text-left" for="rate1">Rate(tk)</label>
                            <?php echo e(Form::text('rate', $product->rate, ['class' => 'form-control','id'=>'rate'])); ?>

                            <?php if($errors->has('rate')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('rate')); ?></strong></span>
                            <?php endif; ?>
                        </div>
                        <!-- Rate ends-->

                        <!-- Total Starts-->
                        <div class="col-md-3 <?php echo e($errors->has('p_total')?'has-error':''); ?>">
                            <label class="control-label text-left" for="p_total1">Total</label>
                            <?php echo e(Form::text('p_total', $product->p_total, ['class' => 'form-control','id'=>'p_total','readonly'])); ?>

                            <?php if($errors->has('p_total')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('p_total')); ?></strong></span>
                            <?php endif; ?>
                        </div>
                        <!-- Total ends-->

                    </div>
                </div>


                <!--REMOVE BUTTON START-->
                <div class="col-md-2 " >
                    <div class="form-group " style="padding-top: 29px;">
                        <button type="button" class="btn btn-danger remove-btn" style="display: inline-block;">Remove</button>
                    </div>
                </div>
                <div class="col-md-12">
                    <hr>
                </div>
                <!--REMOVE BUTTON END-->
            </div>
            <div style="display:none">
                <?php echo e($num++); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="text-center" id="product1">
            <div class="col-md-10">
                <div class="col-md-12 col-md-offset-1" style="padding-left:0; padding-right: 40px;">
                    <div class=" col-md-3">
                        <label class="control-label" for="product_id">Product Name</label>
                        <div class="">
                            <?php echo Form::select('product_id1',$repository->products(),null,['id'=>'product_id1','class'=>'form-control','required','placeholder'=>'Select a product']); ?>

                         </div>
                    </div>

                    <!-- Quantity Starts-->
                    <div class="col-md-3 <?php echo e($errors->has('quantity1')?'has-error':''); ?>">
                        <label class="control-label text-left" for="quantity1">Quantity</label>
                        <?php echo e(Form::text('quantity1', null, ['class' => 'form-control','id'=>'quantity1'])); ?>

                        <?php if($errors->has('quantity1')): ?>
                            <span class="help-block"><strong><?php echo e($errors->first('quantity1')); ?></strong></span>
                        <?php endif; ?>
                    </div>
                    <!-- Quantity ends-->

                    <!-- Rate Starts-->
                    <div class="col-md-3 <?php echo e($errors->has('rate1')?'has-error':''); ?>">
                        <label class="control-label text-left" for="rate1">Rate(tk)</label>
                        <?php echo e(Form::text('rate1', null, ['class' => 'form-control','id'=>'rate1'])); ?>

                        <?php if($errors->has('rate1')): ?>
                            <span class="help-block"><strong><?php echo e($errors->first('rate1')); ?></strong></span>
                        <?php endif; ?>
                    </div>
                    <!-- Rate ends-->

                    <!-- Total Starts-->
                    <div class="col-md-3 <?php echo e($errors->has('p_total1')?'has-error':''); ?>">
                        <label class="control-label text-left" for="p_total1">Total</label>
                        <?php echo e(Form::text('p_total1', null, ['class' => 'form-control','id'=>'p_total1','readonly'])); ?>

                        <?php if($errors->has('p_total1')): ?>
                            <span class="help-block"><strong><?php echo e($errors->first('p_total1')); ?></strong></span>
                        <?php endif; ?>
                    </div>
                    <!-- Total ends-->

                </div>
            </div>


            <!--REMOVE BUTTON START-->
            <div class="col-md-2 " >
                <div class="form-group " style="padding-top: 29px;">
                    <button type="button" class="btn btn-danger remove-btn" style="display: inline-block;">Remove</button>
                </div>
            </div>
            <div class="col-md-12">
                <hr>
            </div>
            <!--REMOVE BUTTON END-->

        </div>
    <?php endif; ?>
</div>
<!--DOOR CLOSE-->


<div class="col-md-12 col-md-offset-1">
    <div class="form-group col-md-2 ">
        <button class="btn btn-primary" onclick="addRow()" type="button">Add more...</button>
    </div>
</div>



<div class="form-group">
    <div class="col-md-2 col-md-offset-3">
        <?php echo e(Form::submit($submitButtonText,['class'=>'form-control btn btn-success'])); ?>

    </div>
    <div class="col-md-2">
        
        <?php echo e(Form::reset('RESET',['class'=>'form-control btn btn-warning'])); ?>

    </div>
    <div class="col-md-2">
        <a href="<?php echo e(URL::previous()); ?>" role="button" class="form-control btn btn-danger">Back</a>
    </div>
</div>
<!-- ends-->


<?php $__env->startSection('script'); ?>
    <script>
        // Add new row
        function addRow(){
            // get the last DIV which ID starts with ^= "product"
            var $div = $('div[id^="product"]:last');

            // Read the Number from that DIV's ID (i.e: 3 from "product3")
            // And increment that number by 1
            var num = parseInt( $div.prop("id").match(/\d+/g), 10 ) +1;

            // Clone it and assign the new ID (i.e: from num 4 to ID "product4")
            var $klon = $div.clone().prop('id', 'product'+num);

            $('select[id^="product_id"]:last').prop('id','product_id'+num).prop('name','product_id'+num);
            $('input[id^="quantity"]:last').prop('id','quantity'+num).prop('name','quantity'+num);
            $('input[id^="rate"]:last').prop('id','rate'+num).prop('name','rate'+num);
            $('input[id^="p_total"]:last').prop('id','p_total'+num).prop('name','p_total'+num);


            // >>> Append $klon wherever you want
            $klon.appendTo($("#door"));
        }
    </script>
    <script>
        // remove "remove button" if only one row left
        $(document).on('click ready',function(){
            if($('div[id^="product"]').length > 1){
                $(".remove-btn").show()
            }else{
                $(".remove-btn").hide()
            }
        });
    </script>
    <script>
        // remove program's row
        setInterval(function(){
            $(".remove-btn").click(function(){
                var $div = $('div[id^="product"]');
                if($div.length > 1){
                    $(this).closest($div).remove()
                }
            });
        },1000)

    </script>



    <script>
        $(document).keyup(function () {
            var total = $('#total').val();
            var advance = $('#advance').val();
            $('#due').val(parseFloat(total) - parseFloat(advance));
        })
    </script>

    
    
    
    
    
    
    
    <script>
        $(document).keyup(function () {
            var $div = $('div[id^="product"]:last');
            var num = parseInt( $div.prop("id").match(/\d+/g), 10 ) +1;
            var total = 0;

            for(var i=1;i<num;i++) {
                var a = $("#product" + i + " input[id^='rate']").val();
                var b = $("#product" + i + " input[id^='quantity']").val();
                var c = $("#product" + i + " input[id^='p_total']").val(parseFloat(a) * parseInt(b));

                if (isNaN(a)) {a = 0}
                if (isNaN(b)) {b = 0}

                $("#product" + i + " input[id^=t]").val(Math.floor(a * b));

                total += Math.floor((a * b));
            }
            $("#total").val(total);
        })
    </script>
    
        
        

        
        
        
        
            
            

            
            

            

            
        
        

    

<?php $__env->stopSection(); ?>