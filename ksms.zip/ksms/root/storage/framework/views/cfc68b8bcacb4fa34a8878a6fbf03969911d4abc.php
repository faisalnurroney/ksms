<?php $__env->startSection('title','Add Company'); ?>

<?php $__env->startSection('content'); ?>

    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Add Company</h2>

            <div class="right-wrapper pull-right">
                <ol class="breadcrumbs">
                    <li>
                        <a href="<?php echo e(url('/home')); ?>">
                            <i class="fa fa-home"></i>
                        </a>
                    </li>
                    <li><a href="<?php echo e(url('/company')); ?>"><span>Company Management</span></a></li>
                    <li><span>Add Company</span></li>
                </ol>

                <a class="sidebar-right-toggle" data-open=""><i class="fa fa-chevron-left"></i></a>
            </div>
        </header>

        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        <div class="panel-actions">
                            <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                            
                        </div>

                        <h2 class="panel-title">Company Details</h2>
                    </header>
                    <div class="panel-body">
                        <?php echo Form::model($company = new \App\Company,['action'=>'CompanyController@store','method'=>'post','class'=>'form-horizontal','files'=>true]); ?>

                        <?php echo $__env->make('company.form',['submitButtonText'=>'Add'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo Form::close(); ?>

                    </div>
                </section>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>