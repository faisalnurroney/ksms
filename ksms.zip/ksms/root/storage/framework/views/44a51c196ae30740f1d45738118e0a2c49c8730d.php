<?php $__env->startSection('title','Purchases'); ?>

<?php $__env->startSection('content'); ?>
    <section role="main" class="content-body">
        <header class="page-header">
            <h2>Dashboard</h2>
            <div class="right-wrapper pull-right">
                <ol class="breadcrumbs">
                    <li>
                        <a>
                            <i class="fa fa-home"></i>
                        </a>
                    </li>
                    <li><span>Invoice</span></li>
                </ol>
                <a class="sidebar-right-toggle" ><i class="fa fa-chevron-left"></i></a>
            </div>
        </header>

        <!-- Search Panel -->
        <div class="panel panel-body no-print">
            <?php echo Form::open(['action'=>'InvoiceController@index','method'=>'get','class'=>'form-inline']); ?>

            <div class="form-group <?php echo e($errors->has('date')?'has-error':''); ?>">
                <label class="control-label">Program Date: </label>
                <div class="input-group">
                <span class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                </span>
                    <?php echo e(Form::text('date', null, array('class' => 'form-control','data-plugin-datepicker data-date-format="yyyy-mm-dd"','placeholder'=>'YYYY-MM-DD' ))); ?>

                </div>
                <?php if($errors->has('date')): ?>
                    <span class="help-block"><strong><?php echo e($errors->first('date')); ?></strong></span>
                <?php endif; ?>
            </div>
            <?php echo Form::submit('GO',['class'=>'btn btn-success']); ?>

            <a href="javascript:window.print()" class="btn btn-success" role="button"><i class="fa fa-print"></i></a>
            <?php echo Form::close(); ?>

        </div>
        <!-- /Search Panel -->

        <div class="row">
            <div class="col-xs-12">
                <section class="panel">
                    <header class="panel-heading">
                        <div class="panel-actions">
                            <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                        </div>
                        <h2 class="panel-title">List of Invoices</h2>
                    </header>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-condensed mb-none">
                                <thead>
                                <tr>
                                    <th class="text-center">ID</th>
                                    <th class="text-center">Date</th>
                                    <th class="text-center">Supplier</th>
                                    <th class="text-center">Voucher</th>
                                    <th class="text-center">Total</th>
                                    <th class="text-center">Paid</th>
                                    <th class="text-center">Due</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($invoice->id); ?></td>
                                        <td><?php echo e($invoice->date); ?></td>
                                        <td><?php echo e($invoice->supplier->supplier_name); ?></td>
                                        <td class="text-center"><?php echo e(Html::linkAction('PurchaseController@show',$invoice->voucher,[$invoice->id])); ?></td>
                                        <td class="text-right"><?php echo e(isset($invoice->total) ? $invoice->total : ''); ?></td>
                                        <td class="text-right"><?php echo e(isset($invoice->advance) ? $invoice->advance : ''); ?></td>
                                        <td class="text-right"><?php echo e(isset($invoice->due) ? $invoice->due : ''); ?></td>
                                        <td class="text-center">
                                            <?php echo e(Form::open(['action'=>['InvoiceController@destroy',$invoice->id],'method'=>'delete','onsubmit'=>'return confirmDelete()'])); ?>

                                            <a href="<?php echo e(action('InvoiceController@edit',$invoice->id)); ?>" role="button" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                            <?php echo e(Form::submit('X',['class'=>'btn btn-danger'])); ?>

                                            <?php echo e(Form::close()); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td colspan="4" class="text-right"><b>Total</b></td>
                                        <td class="text-right"><b><?php echo e($total); ?></b></td>
                                        <td class="text-right"><b><?php echo e($paid); ?></b></td>
                                        <td class="text-right"><b><?php echo e($due); ?></b></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        function confirmDelete(){
            var x = confirm('Are you sure you want to delete this record?');
            return !!x;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>