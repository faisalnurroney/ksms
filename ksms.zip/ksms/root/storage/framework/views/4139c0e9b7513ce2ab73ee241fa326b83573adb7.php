<!-- Vehicle Name Starts-->
<div class="form-group <?php echo e($errors->has('name')? 'has-error':''); ?>">
    <?php echo e(Form::label('name', 'Name:', ['class'=>'col-md-3 control-label'])); ?>

    <div class="col-md-6">
        <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

        <?php if($errors->has('name')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('name')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Vehicle name ends-->
<!-- brand Starts-->
<div class="form-group <?php echo e($errors->has('brand_id')? 'has-error':''); ?>">
    <?php echo e(Form::label('brand_id', 'Brand Name:', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('brand_id',$repository->brands(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select Brand'])); ?>

        <?php if($errors->has('brand_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('brand_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- brand ends-->
<!-- Type start-->
<div class="form-group <?php echo e($errors->has('type_id')? 'has-error':''); ?>">
    <?php echo e(Form::label('type_id', 'Types:', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('type_id',$repository->types(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select Vehicle Type'])); ?>

        <?php if($errors->has('type_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('type_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!-- Types ends-->
<!-- Owner start-->
<div class="form-group <?php echo e($errors->has('owner_id')? 'has-error':''); ?>">
    <?php echo e(Form::label('owner_id', 'Owner:', array('class'=>'col-md-3 control-label'))); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('owner_id',$repository->owners(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select Vehicle Owner'])); ?>

        <?php if($errors->has('owner_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('owner_id')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>

<!-- Owner -->
<!--Road permit starts-->
<div class="form-group <?php echo e($errors->has('roadPermitStart','roadPermitEnd')? 'has-error':''); ?>">
    
    <?php echo e(Form::label('roadPermit','Road Permit:',['class'=>'col-md-3 control-label'])); ?>

    <div class="col-md-6">
        <div class="input-daterange input-group" data-plugin-datepicker data-date-format='yyyy-mm-dd' data-date-format='yyyy-mm-dd'>
            <span class="input-group-addon">
                <i class="fa fa-calendar"></i>
            </span>
            <?php echo e(Form::text('roadPermitStart', null, array('class' => 'form-control'))); ?>

            <span class="input-group-addon">to</span>
            <?php echo e(Form::text('roadPermitEnd', null, array('class' => 'form-control'))); ?>

        </div>
        <?php if($errors->has('roadPermitStart')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('roadPermitStart')); ?></strong></span><br>
        <?php endif; ?>
        <?php if($errors->has('roadPermitEnd')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('roadPermitEnd')); ?></strong></span>
        <?php endif; ?>

    </div>
</div>
<!--Road permit ends-->

<!--Tax Token starts-->
<div class="form-group <?php echo e($errors->has('taxTokenStart','taxTokenEnd')? 'has-error':''); ?>">
    
    <?php echo e(Form::label('taxToken','Tax Token:',['class'=>'col-md-3 control-label'])); ?>

    <div class="col-md-6">
        <div class="input-daterange input-group" data-plugin-datepicker data-date-format='yyyy-mm-dd'>
            <span class="input-group-addon">
                <i class="fa fa-calendar"></i>
            </span>
            <?php echo e(Form::text('taxTokenStart', null, array('class' => 'form-control'))); ?>

            <span class="input-group-addon">to</span>
            <?php echo e(Form::text('taxTokenEnd', null, array('class' => 'form-control'))); ?>

        </div>
        <?php if($errors->has('taxTokenStart')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('taxTokenStart')); ?></strong></span><br>
        <?php endif; ?>
        <?php if($errors->has('taxTokenEnd')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('taxTokenEnd')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!--Road permit ends-->
<!--Road permit starts-->
<div class="form-group <?php echo e($errors->has('insuranceStart','insuranceEnd')? 'has-error':''); ?>">
    
    <?php echo e(Form::label('insurance','Insurance:',['class'=>'col-md-3 control-label'])); ?>

    <div class="col-md-6">
        <div class="input-daterange input-group" data-plugin-datepicker data-date-format='yyyy-mm-dd'>
            <span class="input-group-addon">
                <i class="fa fa-calendar"></i>
            </span>
            <?php echo e(Form::text('insuranceStart', null, array('class' => 'form-control'))); ?>

            <span class="input-group-addon">to</span>
            <?php echo e(Form::text('insuranceEnd', null, array('class' => 'form-control'))); ?>

        </div>
        <?php if($errors->has('insuranceStart')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('insuranceStart')); ?></strong></span><br>
        <?php endif; ?>
        <?php if($errors->has('insuranceEnd')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('insuranceEnd')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!--Road permit ends-->

<!--Fitness starts-->
<div class="form-group <?php echo e($errors->has('fitnessStart','fitnessEnd')? 'has-error':''); ?>">
    
    <?php echo e(Form::label('fitness','Fitness:',['class'=>'col-md-3 control-label'])); ?>

    <div class="col-md-6">
        <div class="input-daterange input-group" data-plugin-datepicker data-date-format='yyyy-mm-dd'>
            <span class="input-group-addon">
                <i class="fa fa-calendar"></i>
            </span>
            <?php echo e(Form::text('fitnessStart', null, array('class' => 'form-control'))); ?>

            <span class="input-group-addon">to</span>
            <?php echo e(Form::text('fitnessEnd', null, array('class' => 'form-control'))); ?>

        </div>
        <?php if($errors->has('fitnessStart')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('fitnessStart')); ?></strong></span><br>
        <?php endif; ?>
        <?php if($errors->has('fitnessEnd')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('fitnessEnd')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!--Fitness ends-->

<!--Registration Certificate starts-->
<div class="form-group <?php echo e($errors->has('regCertStart','regCertEnd')? 'has-error':''); ?>">
    <label class="col-md-3 control-label">Registration Certification</label>
    <div class="col-md-6">
        <div class="input-daterange input-group" data-plugin-datepicker data-date-format='yyyy-mm-dd'>
            <span class="input-group-addon">
                <i class="fa fa-calendar"></i>
            </span>
            <?php echo e(Form::text('regCertStart', null, array('class' => 'form-control'))); ?>

            <span class="input-group-addon">to</span>
            <?php echo e(Form::text('regCertEnd', null, array('class' => 'form-control'))); ?>

        </div>
        <?php if($errors->has('regCertStart')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('regCertStart')); ?></strong></span><br>
        <?php endif; ?>
        <?php if($errors->has('regCertEnd')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('regCertEnd')); ?></strong></span>
        <?php endif; ?>
    </div>
</div>
<!--Registration Certificate ends-->

<!-- Vehicle Number Starts-->
<div class="form-group <?php echo e($errors->has('vehicleNo')? 'has-error':''); ?>">

    <label class="col-md-3 control-label">Vehicle Number</label>
    <div class="col-md-6">
        <?php echo e(Form::text('vehicleNo',null, array('class' => 'form-control'))); ?>

        <?php if($errors->has('vehicleNo')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('vehicleNo')); ?></strong></span><br>
        <?php endif; ?>
    </div>
</div>
<!-- Vehicle number ends-->

<!-- Engine Number Starts-->
<div class="form-group <?php echo e($errors->has('engineNo')? 'has-error':''); ?>">
    <label class="col-md-3 control-label">Engine Number</label>
    <div class="col-md-6">
        <?php echo e(Form::text('engineNo',null, array('class' => 'form-control'))); ?>

        <?php if($errors->has('engineNo')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('engineNo')); ?></strong></span><br>
        <?php endif; ?>
    </div>
</div>
<!-- Engine Number ends-->

<!-- Chesis Number Starts-->
<div class="form-group <?php echo e($errors->has('chasesNo')? 'has-error':''); ?>">
    <label class="col-md-3 control-label">Chases Number</label>
    <div class="col-md-6">
        <?php echo e(Form::text('chasesNo',null, array('class' => 'form-control'))); ?>

        <?php if($errors->has('chasesNo')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('chasesNo')); ?></strong></span><br>
        <?php endif; ?>
    </div>
</div>
<!-- Chesis Number ends-->

<!-- Mobile Number Starts-->
<div class="form-group <?php echo e($errors->has('mobile')? 'has-error':''); ?>">
    <label class="col-md-3 control-label">Mobile Number</label>
    <div class="col-md-6">
        <?php echo e(Form::text('mobile',null, array('class' => 'form-control'))); ?>

        <?php if($errors->has('mobile')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('mobile')); ?></strong></span><br>
        <?php endif; ?>
    </div>
</div>
<!-- Mobile Number ends-->

<!-- Status Starts-->
<div class="form-group <?php echo e($errors->has('status_id')? 'has-error':''); ?>">
    <label class="col-md-3 control-label">Status</label>
    <div class="col-md-6">
        <?php echo e(Form::select('status_id',$repository->status(),null,['class'=>'form-control populate','data-plugin-selectTwo','placeholder'=>'Select a status'])); ?>

        <?php if($errors->has('status_id')): ?>
            <span class="help-block"><strong><?php echo e($errors->first('status_id')); ?></strong></span><br>
        <?php endif; ?>
    </div>
</div>
<!-- Status ends-->
<div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
    <label class="col-md-3 control-label" for="image">Image<span class="required">*</span>:</label>
    <div class="col-md-9">
        <?php echo Form::file('image',['onchange'=>'readURL(this)']); ?>

        <?php if($errors->has('image')): ?>
            <span class="help-block">
                    <strong><?php echo e($errors->first('image')); ?></strong>
                </span>
        <?php endif; ?>
        <img src="<?php echo e(asset('/images/vehicles/')); ?>/<?php echo e($vehicle->image != null ? $vehicle->image : 'demo.png'); ?>" id="image" class="img-thumbnail" width="265" alt=""/>
    </div>
</div>
<!--Submit button -->
<div class="form-group">
    <div class="col-md-2 col-md-offset-3">
        <?php echo e(Form::submit($submitButtonText,['class'=>'form-control btn btn-success'])); ?>

    </div>
    <div class="col-md-2">
        <?php echo e(Form::reset('Reset',['class'=>'form-control btn btn-warning'])); ?>

    </div>
    <div class="col-md-2">
        <a href="<?php echo e(URL::previous()); ?>" role="button" class="form-control btn btn-danger">Cancel</a>
    </div>
</div>
<!-- ends-->

<?php $__env->startSection('script'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {

                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#image').attr('src', e.target.result).width(150).height(150);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
<?php $__env->stopSection(); ?>