<!-- start: sidebar -->
<aside id="sidebar-left" class="sidebar-left">
    <div class="sidebar-header">
        <div class="sidebar-title">
            Navigation
        </div>
        <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
            <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
        </div>
    </div>

    <div class="nano">
        <div class="nano-content">
            <nav id="menu" class="nav-main" role="navigation">
                <ul class="nav nav-main">
                    <li class="<?php echo e(isActive('/')); ?>">
                        <a href="<?php echo e(url('/')); ?>">
                            <i class="fa fa-home" aria-hidden="true"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    
                        
                            
                            
                            
                        
                    
                    <li class="nav-parent">
                        <a>
                            <i class="fa fa-users" aria-hidden="true"></i>
                            <span>Employee</span>
                        </a>
                        <ul class="nav nav-children">
                            <li>
                                <a href="pages-signup.html">
                                    Employees
                                </a>
                            </li>
                            <li>
                                <a href="pages-signup.html">
                                    Add Employee
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent">
                        <a>
                            <i class="fa fa-user" aria-hidden="true"></i>
                            <span>User</span>
                        </a>
                        <ul class="nav nav-children">
                            <li>
                                <a href="ui-elements-typography.html">
                                    Users
                                </a>
                            </li>
                            <li>
                                <a>
                                    Add User
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent <?php echo e(isActive(['vehicle*','brand*','type*','status*'])); ?>">
                        <a>
                            <i class="fa fa-users" aria-hidden="true"></i>
                            <span>Vehicle</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('vehicles')); ?>">
                                <a href="<?php echo e(action('VehicleController@index')); ?>">
                                    Vehicle Information
                                </a>
                            </li>
                            <li class="<?php echo e(isActive('vehicle/create')); ?>">
                                <a href="<?php echo e(action('VehicleController@create')); ?>">Add Vehicle</a>
                            </li>
                            <li class="<?php echo e(isActive('brand/create')); ?>">
                                <a href="<?php echo e(action('BrandController@create')); ?>">Brand</a>
                            </li>
                            <li class="<?php echo e(isActive('type/create')); ?>">
                                <a href="<?php echo e(action('TypeController@create')); ?>">Type</a>
                            </li>
                            <li class="<?php echo e(isActive('status/create')); ?>">
                                <a href="<?php echo e(action('StatusController@create')); ?>">Status</a>
                            </li>
                        </ul>
                    </li>
                    
                    
                    <li class="nav-parent <?php echo e(isActive(['owner*'])); ?>">
                        <a>
                            <i class="fa fa-users" aria-hidden="true"></i>
                            <span>Owner</span>
                        </a>
                        <ul class="nav nav-children">
                            <li class="<?php echo e(isActive('owners')); ?>">
                                <a href="<?php echo e(action('OwnerController@index')); ?>">Owner</a>
                            </li>
                            <li class="<?php echo e(isActive('owner/create')); ?>">
                                <a href="<?php echo e(action('OwnerController@create')); ?>">Add Owner</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-parent">
                        <a>
                            <i class="fa fa-th-list" aria-hidden="true"></i>
                            <span>Inventory</span>
                        </a>
                        <ul class="nav nav-children">
                            <li>
                                <a href="ui-elements-typography.html">
                                    Add Product
                                </a>
                            </li>
                            <li>
                                <a href="ui-elements-typography.html">
                                    Category
                                </a>

                            </li>
                            <li>
                                <a>
                                    Sub Category
                                </a>
                            </li>
                            <li>
                                <a>
                                    Brands
                                </a>

                            </li>
                            <li>
                                <a>
                                    Size
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-parent">
                        <a>
                            <i class="fa fa-briefcase" aria-hidden="true"></i>
                            <span>Suppliers</span>
                        </a>
                        <ul class="nav nav-children">
                            <li>
                                <a href="ui-elements-typography.html">
                                    Supplier list
                                </a>

                            </li>
                            <li>
                                <a>
                                    Add Supplier
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <a>
                            <i class="fa fa-credit-card" aria-hidden="true"></i>
                            <span>Purchase</span>
                        </a>
                        
                            
                                
                                    
                                

                            
                            
                                
                                    
                                
                            
                        
                    </li>

                    
                        
                            
                            
                        
                        
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                                
                                    
                                        
                                            
                                        
                                    
                                    
                                        
                                            
                                        
                                    
                                
                            
                            
                                
                                    
                                
                                
                                    
                                        
                                            
                                        
                                    
                                    
                                        
                                            
                                        
                                    
                                
                            
                            
                                
                                    
                                
                            
                        
                    

                    
                        
                            
                            
                        
                        
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                        
                    
                    
                        
                            
                            
                        
                        
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                        
                    
                    
                        
                            
                            
                        
                        
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                        
                    
                    
                        
                            
                            
                        
                        
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                        
                    
                    
                        
                            
                            
                        
                        
                            
                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                        
                    
                    
                        
                            
                            
                        
                    
                    
                        
                            
                            
                        
                        
                            
                                
                            
                            
                                
                                
                                    
                                        
                                        
                                            
                                                
                                            
                                            
                                                
                                            
                                        
                                    
                                    
                                        
                                    
                                    
                                        
                                    
                                
                            
                        
                    
                </ul>
            </nav>

            

            
                
                    
                    
                
                
                    
                        
                        
                        
                    
                
            

            

            
                
                    
                    
                
                
                    
                        
                            
                            
                            
                                
                                    
                                
                            
                        
                        
                            
                            
                            
                                
                                    
                                
                            
                        
                        
                            
                            
                            
                                
                                    
                                
                            
                        
                    
                </div>
            </div>
        </div>

    </div>

</aside>
<!-- end: sidebar -->

<section role="main" class="content-body">
    <header class="page-header">
        <h2>Dashboard</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a>
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Dashboard</span></li>
            </ol>

            <a class="sidebar-right-toggle" ><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
</section>