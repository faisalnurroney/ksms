<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes();

Route::get('/', 'HomeController@index')->name('home');
Route::get('/home', 'HomeController@index')->name('home');

//designation routes
Route::get('designations', 'DesignationController@index');
Route::post('designation/store', 'DesignationController@store');
Route::get('designation/edit/{id}','DesignationController@edit');
Route::patch('designation/{id}/update','DesignationController@update');
Route::delete('designation/delete/{id}','DesignationController@destroy');


//Employee routes
Route::get('employees', 'EmployeeController@index');
Route::get('employee/create', 'EmployeeController@create');
Route::post('employee/store', 'EmployeeController@store');
Route::get('employee/edit/{id}','EmployeeController@edit');
Route::patch('employee/{id}/update','EmployeeController@update');
Route::delete('employee/delete/{id}','EmployeeController@destroy');

//Program routes
Route::get('programs', 'ProgramController@index');
Route::get('program/create', 'ProgramController@create');
Route::post('program/store', 'ProgramController@store');
Route::get('program/edit/{id}','ProgramController@edit');
Route::patch('program/{id}/update','ProgramController@update');
Route::delete('program/delete/{id}','ProgramController@destroy');
Route::get('program/rotation','ProgramController@rotation');
Route::get('program/report','ProgramController@programReport');
Route::get('program/receipt','ProgramController@driverReceipt');
Route::get('program/dailyReport','ProgramController@dailyReport');
Route::get('program/dailyIncomeReport','ProgramController@dailyIncomeReport');
Route::get('program/show/{id}','ProgramController@show');

//Trip routes
Route::get('trips', 'TripController@index');
Route::get('trip/create', 'TripController@create');
Route::post('trip/store', 'TripController@store');
Route::get('trip/edit/{id}','TripController@edit');
Route::patch('trip/{id}/update','TripController@update');
Route::delete('trip/delete/{id}','TripController@destroy');

/** Company Route */
Route::get('companies', 'CompanyController@index');
Route::get('company/create', 'CompanyController@create');
Route::post('company/store', 'CompanyController@store');
Route::get('company/edit/{id}','CompanyController@edit');
Route::patch('company/{id}/update','CompanyController@update');
Route::delete('company/delete/{id}','CompanyController@destroy');
Route::get('company/show/{id}','CompanyController@show');

/** User Routes */
Route::get('users','UserController@index');
Route::get('user/create','UserController@create');
Route::post('user/store','UserController@store');
Route::get('user/show/{id}','UserController@show');
Route::get('user/edit/{id}','UserController@edit');
Route::patch('user/{id}/update','UserController@update');
Route::patch('user/{id}/reset','UserController@resetPassword');
Route::get('user/change','UserController@changePassword');
Route::patch('user/new','UserController@newPassword');
Route::delete('user/destroy/{id}','UserController@destroy');