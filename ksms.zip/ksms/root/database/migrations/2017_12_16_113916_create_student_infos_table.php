<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStudentInfosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('student_infos', function (Blueprint $table) {
            $table->increments('id');
            $table->authorities();
            $table->integer('student_id')->unique();
            $table->integer('roll');
            $table->string('name');
            $table->string('name_bangla');
            $table->string('f_name');
            $table->string('f_name_bangla');
            $table->string('m_name');
            $table->string('m_name_bangla');
            $table->date('dob');
            $table->integer('class_id')->unsigned();
            $table->string('section');
            $table->integer('group_id')->unsigned();
            $table->string('gender');
            $table->string('session');
            $table->integer('old_roll');
            $table->integer('new_roll');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('student_infos');
    }
}
