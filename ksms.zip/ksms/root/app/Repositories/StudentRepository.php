<?php


namespace App\Repositories;

use App\Designation;

class EmployeeRepository {

    public function groups(){
        return Group::all()->pluck('name','id');
    }

    public function sections()
    {
        $section = ['A'=>'A','B'=>'B','C'=>'C','D'=>'D','E'=>'E','F'=>'F'];

        return $section;
    }
}